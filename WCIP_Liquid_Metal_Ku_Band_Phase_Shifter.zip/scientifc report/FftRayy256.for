
       SUBROUTINE RAY1(a,v3,n01,n02,Freq,IParois,
     &                                ZEIx,ZEIz,
     &                              ZEIIx,ZEIIz)

C   �������������������������������������������������������������ͻ
C   �                                                             �
C   �  |        MISE EN OEUVRE DE LA METHODE ITERATIVE         |  �
C   �  |   CALCUL DU DIAGRAMME DE RAYONNEMENT D UNE ANTENNE    |  �
C   �  |   PLANAIRE UTILISANT LA DECOMPOSITION DU CHAMP ELEC   |  �
C   �  |   DANS LA BASE DES FONCTIONS DE MODES TE & TM EN      |  �
C   �  |               UTILISANT LA FFT EN MODE                |  �
C   �                                                             �
C   �    ------------------- &&&-------&&&--------------------    �
C   �                                                             �
C   �  |     N"gongo Simplice Rufin. Ph.D.                     |  �
C   �  |     ENSEEIHT-INPT                                     |  �
C   �  |     All rights reserved. Protected by Copyright       |  �
C   �  |     Date: Juin  1998                                  |  �
C   �        ---------------- &&& -------------------             �
C   �                                                             �
C   �������������������������������������������������������������ͼ
      
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER (Nmx=21,DZero=0.d0,Cel=3.D8)
      DIMENSION T11r(n01,n02),T12r(n01,n02)
      DIMENSION T21r(n01,n02),T22r(n01,n02)
      DIMENSION ZEIx(n01,n02),ZEIz(n01,n02)
      DIMENSION ZEIIx(n01,n02),ZEIIz(n01,n02)
      DIMENSION ZEIte(n01,n02),ZEIth(n01,n02)
      DIMENSION ZEIIte(n01,n02),ZEIIth(n01,n02)
      DIMENSION ZIEx(n01,n02),ZIEz(n01,n02)
	DIMENSION ZIIEx(n01,n02),ZIIEz(n01,n02)
      DIMENSION E1ray(Nmx+1,Nmx+1),E2ray(Nmx+1,Nmx+1)
      DIMENSION E11ray(Nmx+1,Nmx+1),E12ray(Nmx+1,Nmx+1)
      Zero=DCMPLX(DZero,DZero)        

	E1Max=DZero
	E2Max=DZero
	E11Max=DZero
	E12Max=DZero
      
      OPEN(7,File='rayx',Status='Unknown')
	OPEN(8,File='rayx1',Status='Unknown')
	OPEN(9,File='rayh',Status='Unknown')
	OPEN(10,File='rayh1',Status='Unknown')



							 Pi=4.D0*DATan(1.D0) 	
                               Cte=a*v3/(Dble(n01)*Dble(n02))
                               DKo=2*Pi*Freq*1.d9/Cel
                                
           
C		-------------------------- &&&-------&&&----------------------    
C	    | 														     |
C         |            CALCUL DES PRODUITS DE RAYONNEMENT              |
C	    |														     |
C         | <fmnxTE/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   
C         | <fmnyTE/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   
C         | <fmnxTM/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   
C         | <fmnyTM/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   
C	    |															 |
C         -------------------------- &&&-------&&&----------------------

	write(*,*)
	write(*,*)
	write(*,*)
	write(*,*)
	write(*,*)

      write(*,'(/t15,a,\)')'�����������������������������������������ͻ'
      write(*,'(/t15,a,\)')'�                                         �'
      write(*,'(/t15,a,\)')'� |                                      |�'
      write(*,'(/t15,a,\)')'� |  CALCUL DU DIAGRAMME DE RAYONNEMENT  |�'
      write(*,'(/t15,a,\)')'� |     D UNE ANTENNE PLANAIRE PAR LA    |�'
	write(*,'(/t15,a,\)')'� |                                      |�'
	write(*,'(/t15,a,\)')'� |         FAST MODAL TRANSFORM         |�'
	write(*,'(/t15,a,\)')'� |                                      |�'
      write(*,'(/t15,a,\)')'� |             -- F.M.T --              |�'
      write(*,'(/t15,a,\)')'�                                         �'
      write(*,'(/t15,a,\)')'�   ------------- &&&-------&&&---------- �'
      write(*,'(/t15,a,\)')'�                                         �'
      write(*,'(/t15,a,\)')'� |    N"gongo Simplice Rufin.           |�'
      write(*,'(/t15,a,\)')'� |     ENSEEIHT-INPT                    |�'
      write(*,'(/t15,a,\)')'� |     All rights reserved. Copyright   |�'
      write(*,'(/t15,a,\)')'� |     Date: Juin  1998                 |�'
      write(*,'(/t15,a,\)')'�                                         �'
      write(*,'(/t15,a,\)')'�����������������������������������������ͼ'

	write(*,*)
 	write(*,*)
	write(*,*)
	write(*,*)
	write(*,*)

C             --- &&& ----------- &&& ---------- &&& ---            


C       ������������������������������������������������������������������ͻ
C       �                                                                  �
C       � TRANSFORMEE DE FOURIER DIRECTE (EN MODE) DE L'ONDE INCIDENTE ZA  �
C       �      =====================================================       �
C       �                                                                  �

               CALL MATRICE_DE_MODE(n01,n02,a,v3,IParois,
     &							 	        ZEIx,ZEIIx,
     &								  	    ZEIz,ZEIIz,
     &									  ZEIte,ZEIIte,
     &									  ZEIth,ZEIIth)


C             --- &&& ----------- &&& ---------- &&& ---          

C       �                                                                  �
C       ������������������������������������������������������������������ͼ 




	 Do 21 i=1,Nmx+1
c       Do 21 j=1,Nmx+1
              Do 21 j=Nmx+1

	           ZE1x=Zero
                 ZE1z=Zero
	           ZE2x=Zero
                 ZE2z=Zero
 			   
C             --- &&& ---- ANGLES D OUVERTURE ---- &&& ---

              DTetha=(i-1)*Pi/DBle(Nmx)-pi/2.d0
              DPhi=(j-1)*Pi/DBle(Nmx)-pi/2.d0


C             --- &&& ----------- &&& ---------- &&& ---

             Do 14 m=1,n01
             Do 14 n=1,n02

	   
C	&&& ======= Suivant (ox)  

C        �  | <CoSi/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   �


        If((m.EQ.1).AND.(DSin(DTetha).EQ.DZero))Then

				        Zfmnxx=DCMPLX(a,DZero)   
	         	
				                               Else
												   
	  If((m.EQ.1).AND.(DCos(DPhi).EQ.DZero))Then
	  
	                 Zfmnxx=DCMPLX(a,DZero)
	

											  Else
	 
 
                    DT1x=Dko*Dsin(Dtetha)*Dcos(Dphi)
                    ZT2x=DCMPLX(DZero,-DT1x*a)
                    ZT3x=1.d0-DCos((m-1)*Pi)*Exp(ZT2x)
                    DT4x=((m-1)*Pi/a)**2-DT1x**2
                    Zfmnxx=DCMPLX(DZero,DT1x)*ZT3x/DT4x
	
        Endif
	  Endif
	 
        
	  If((n.EQ.1).AND.(DSin(DTetha).EQ.DZero))Then

	                    Zfmnxy=Zero

    										      Else
     			       
        If((n.EQ.1).AND.(DSin(DPhi).EQ.DZero))Then

	                    Zfmnxy=Zero
												  
			 							      Else
	
                    DT12x=Dko*Dsin(Dtetha)*Dsin(Dphi)
                    ZT22x=DCMPLX(DZero,-DT12x*v3)
                    ZT32x=1.d0-DCos((n-1)*Pi)*Exp(ZT22x)
                    DT42x=((n-1)*Pi/v3)**2-DT12x**2
		          Zfmnxy=((n-1)*Pi/v3)*ZT32x/DT42x
                        
        Endif
	  Endif
	 	
C       &&& ======= Suivant (oy)

C        �  | <SiCo/Exp(-jko(xSin(tetha)Cos(DPhi)+ySin(tetha)Sin(DPhi) |   �

		  
		If((m.EQ.1).AND.(DSin(DTetha).EQ.Dzero))Then

						Zfmnyx=Zero
		
												   Else
												   	
		If((m.EQ.1).AND.(DCos(DPhi).EQ.Dzero)) Then

			 	        Zfmnyx=Zero
  											   Else
	        

                    DT1y=Dko*Dsin(Dtetha)*DCos(Dphi)
                    ZT2y=DCMPLX(Dzero,-DT1y*a)
                    ZT3y=1.d0-DCos((m-1)*Pi)*Exp(ZT2y)
                    DT4y=((m-1)*Pi/a)**2-DT1y**2
                    Zfmnyx=((m-1)*Pi/a)*ZT3y/DT4y

        Endif
	  Endif



        If((n.EQ.1).AND.(DSin(DTetha).EQ.DZero))Then
	  
  		  					Zfmnyy=DCMPLX(v3,DZero)

		  									  Else
	

     	  If((n.EQ.1).AND.(DSin(DPhi).EQ.DZero))Then

			  					Zfmnyy=DCMPLX(v3,DZero)

		  										  Else
	


                    DT12y=Dko*Dsin(Dtetha)*DSin(Dphi)
                    ZT22y=DCMPLX(DZero,-DT12y*v3)
                    ZT32y=1.d0-DCos((n-1)*Pi)*Exp(ZT22y)
                    DT42y=((n-1)*Pi/v3)**2-DT12y**2
                    Zfmnyy=DCMPLX(DZero,DT12y)*ZT32y/DT42y
	
        Endif
	  Endif

                    Zfmnx=Zfmnxx*Zfmnxy
                    Zfmny=Zfmnyx*Zfmnyy


C        �����������������������������������������������������������ͻ 
C        �                                                           �
C        �-* CALCUL DES COEFFICIENTS DES FONCTIONS DE MODE TE &TM *- �
C        �     *-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*     � 
C        �                                                           �
C        �����������������������������������������������������������ͼ 

          
		      If((m.NE.1).OR.(n.NE.1)) Then 
 
                  DNorm=DSQRT(((m-1)/a)**2+((n-1)/v3)**2)
                      
                                   DNorm=1.d0/DNorm
                                                                                                                                                 
                                                Else 
                                   DNorm=DZero
                                                
                     Endif                                             


                          If((m-1)*(n-1).EQ.0)   Then
                           Sigma=1.d0
                                                 Else
                           Sigma=2.d0

                                                 Endif

         T11r(m,n)=-(n-1)/v3*DNorm*DSQRT(2*Sigma/(a*v3))*Cte
	   T12r(m,n)=(m-1)/a*DNorm*DSQRT(2*Sigma/(a*v3))*Cte
         T21r(m,n)=(m-1)/a*DNorm*DSQRT(2*Sigma/(a*v3))*Cte
         T22r(m,n)=(n-1)/v3*DNorm*DSQRT(2*Sigma/(a*v3))*Cte
        

c        �  |    CALCUL DES COMPOSANTES DU CHAMP RAYONNE    |   �

		
      ZIEx(m,n)=(T11r(m,n)*ZEIte(m,n)+T12r(m,n)*ZEIth(m,n))*Zfmnx
      ZIEz(m,n)=(T21r(m,n)*ZEIte(m,n)+T22r(m,n)*ZEIth(m,n))*Zfmny

      ZIIEx(m,n)=(T11r(m,n)*ZEIIte(m,n)+T12r(m,n)*ZEIIth(m,n))*Zfmnx
      ZIIEz(m,n)=(T21r(m,n)*ZEIIte(m,n)+T22r(m,n)*ZEIIth(m,n))*Zfmny

                     ZE1x=ZE1x+ZIEx(m,n)
                     ZE1z=ZE1z+ZIEz(m,n)

				   ZE2x=ZE2x+ZIIEx(m,n)
                     ZE2z=ZE2z+ZIIEz(m,n)
				   
C	If((j.EQ.1).OR.(j.EQ.Nmx/4+1))Then	
  
C                     ZEE1x=ZEE1x+ZIEx(m,n)
C                     ZEE1z=ZEE1z+ZIEz(m,n)

C				    ZEE2x=ZEE2x+ZIIEx(m,n)
C                     ZEE2z=ZEE2z+ZIIEz(m,n)

C	Endif
    

  14   CONTINUE

			 E1ray(i,j)=(CDABS(ZE1x**2+ZE1z**2))**2
			 E1Max=DMAX1(E1Max,E1ray(i,j))
	               
			 E2ray(i,j)=(CDABS(ZE2x**2+ZE2z**2))**2
			 E2Max=DMAX1(E2Max,E2ray(i,j))

			 E11ray(i,j)=CDABS(ZE1x*DCos(DPhi)-ZE1z*Dsin(DPhi))**2
			 E12ray(i,j)=CDABS(ZE1x*DCos(DPhi)+ZE1z*Dsin(DPhi))**2

			 E11Max=DMAX1(E11Max,E11ray(i,j))
			 E12Max=DMAX1(E12Max,E12ray(i,j))

 21   CONTINUE

	    Do 71 i=1,Nmx+1
c          Do 71 j=1,Nmx+1
              do 71   j=Nmx+1
             		
			E1ray(i,j)=20.d0*DLOG10(E1ray(i,j)/E1Max)
			E2ray(i,j)=20.d0*DLOG10(E2ray(i,j)/E2Max)

			E11ray(i,j)=20.d0*DLOG10(E11ray(i,j)/E11Max)
			E12ray(i,j)=20.d0*DLOG10(E12ray(i,j)/E12Max)
      
 71   CONTINUE

      Do 72 i=1,Nmx+1
      DTeth=((i-1)*180/DBle(Nmx))-90
 
	
 72   continue


	write(7,27)((E1ray(i,j),i=1,Nmx+1),j=1,Nmx+1)
	
	write(8,27)((E2ray(i,j),i=1,Nmx+1),j=1,Nmx+1)
      
	write(9,27)((E11ray(i,j),j=1,Nmx+1),i=1,Nmx+1)
	
	write(10,27)((E12ray(i,j),j=1,Nmx+1),i=1,Nmx+1)
	
 
 27   Format(21(f14.6,1x)) 
                                     

      End
         
 
