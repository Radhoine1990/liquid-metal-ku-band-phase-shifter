
C	 ****************************************
C	 *  Author : COHEN Ludovic				*
C	 *  Date   : Juin 1999					*
C	 ****************************************

	SUBROUTINE tpsexec (itmpyear1,itmpmonth1,itmpday1,dj1,
     &				    itmphour1,itmpminute1,itmpsecond1,
     &				    itmpyear2,itmpmonth2,itmpday2,dj2,
     &				    itmphour2,itmpminute2,itmpsecond2)

C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
	IMPLICIT INTEGER (I)

C     *****************************************************************************  

    	itmpy=itmpyear2-itmpyear1
	itmpm=itmpmonth2-itmpmonth1			
	itmpd=itmpday2-itmpday1
	itmph=itmphour2-itmphour1
	itmpmin=itmpminute2-itmpminute1
	itmpsec=itmpsecond2-itmpsecond1
	if (dj1.NE.dj2) then
		itmph=itmph+12
	else
		itmph=itmph
	endif
	if (itmpsec.LT.0) then
		itmpmin=itmpmin-1
		itmpsec=itmpsec+60
	else
		itmpsec=itmpsec
	endif
	if (itmpmin.LT.0) then
		itmph=itmph-1
		itmpmin=itmpmin+60
	else
		itmpmin=itmpmin
	endif
	if (itmph.LT.0) then
		itmpd=itmpd-1
		itmph=itmph+24
	else
		itmpd=itmpd
	endif
	if (itmph.LT.0) then
		itmpm=itmpm-1
		itmpd=itmpd+31
	else
		itmpd=itmpd
	endif

	write(*,900) itmpm,itmpd,itmpy
	write(*,901) itmph,itmpmin,itmpsec

C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 900  Format(I2,'/',I2.2,'/',I4.4) 
 901  Format(I3,':',I2.2,':',I2.2) 
 
      END   
	                                      
C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE horaire (itmpyear,itmpmonth,itmpday,dj,
     &					itmphour,itmpminute,itmpsecond,itmphund)

C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	IMPLICIT INTEGER (I)

C     *****************************************************************************  

      call getdat(itmpyear,itmpmonth,itmpday)
	call gettim(itmphour,itmpminute,itmpsecond,itmphund)
   	if (itmphour.GT.12) then
		mer='p'
		dj=2.d0
		itmphour=itmphour-12
	else
		mer='a'
		dj=1.d0
		itmphour=itmphour
	endif

	write(*,900) itmpmonth,itmpday,itmpyear
	write(*,901) itmphour,itmpminute,itmpsecond,itmphund,mer

C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 900  Format(I2,'/',I2.2,'/',I4.4) 
 901  Format(I3,':',I2.2,':',I2.2,':',I2.2,' ',A,'m') 
 
      END          
