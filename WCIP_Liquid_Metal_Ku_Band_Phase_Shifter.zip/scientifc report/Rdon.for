
*********************************************************************
*     Saisie des donnees pour la ligne microruban                   *
*     Date: Aout 1990                                               *
*     --------------------------------------------------------------*
*     ARGUMENTS UTILISES                                            *
*     --------------------------------------------------------------*
*     Dans l'ordre d'apparition dans le fichier de donnees mrdon.dat*
*              a,v3: largeur et longueur du boitier                 *
*       bi {i=1,2,3,...}: les hauteurs des diff couches di�lect     *

*        Dmilieu : les permittivites des substrats dielectriques    *
*********************************************************************

      SUBROUTINE FFTDON(a,b,v1,v2,v3,v4,Dmil1,Dmil2,Dmil3,Dmil4,
     &									 w,s,LouC,epmet,sigma)

      IMPLICIT DOUBLE PRECISION (A-H,O-S,U-Z),CHARACTER (L)
      IMPLICIT LOGICAL (T)
      PARAMETER (Cel=3.D8)
      Pi=4.D0*DATan(1.D0)

      OPEN(1,STATUS='OLD',FILE='donnee.dat')

	read(1,*)
      read(1,*)a
	read(1,*)b
      read(1,*)v1
      read(1,*)v2
      read(1,*)v3
      read(1,*)v4
      read(1,*)Dmil1
      read(1,*)Dmil2
      read(1,*)Dmil3
      read(1,*)Dmil4
      read(1,*)w
      read(1,*)s
      read(1,*)LouC
  	read(1,*)epmet
	read(1,*)sigma

      END
