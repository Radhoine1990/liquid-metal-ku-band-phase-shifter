	SUBROUTINE Zcaracter (Iligne,f,w,dslot,h,hb,Er,dZoI,DZoII,
     &					  dZcpart,dZc,Eeff,epaisseurmetal)						
	
C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLEPRECISION (A-H,O-Y)
      IMPLICIT DOUBLECOMPLEX (Z)
	IMPLICIT INTEGER (I)

      If (Iligne.EQ.1) then
		epaisseurmetal=5.d-6
		CALL zcur (f,w,h,epaisseurmetal,hb,Er,dZoI,dZc,Eeff)
	Endif
	If (Iligne.EQ.2) then
		CALL zccoplan (w,dslot,h,Er,dZc,Eeff)
	Endif
	If (Iligne.EQ.3) then
		dZc=DZoI*DZoII/(DZoI+DZoII)
		Eeff=(Er+1.d0)/2.d0
	Endif
	If (Iligne.EQ.4) then
		dZc=dZcpart
		Eeff=(Er+1.d0)/2.d0
	Endif
	write(*,*)'Zc=',dZc,'	Eeff=',Eeff

C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 
      END   

C     **********************************************      
C     *-----*     nouveau sous-programme     *-----* 
C     **********************************************      

	SUBROUTINE zcur (f,w,h,b,hb,Er,dZoI,dZc,Eef)
			
C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	IMPLICIT INTEGER (I)
   
      PARAMETER (pas=3.125)  
	
	cel=3.D8
	pi=4.D0*datan(1.D0)
	rap=h/w
	rapp=w/h

C     ************************ CALCUL DE EPSILON EFFECTIF SIMPLE ****************  

	if (rapp.GE.1.d0) then
		fonc=1.d0/dsqrt(1.d0+12.d0*rap)
	else	
		fonc=1.d0/dsqrt(1.d0+12.d0*rap)+0.04d0*(1.d0-rapp)**2
	endif 
	Eboitier=dtanh(0.18d0+(0.235d0*(hb/b))-(0.415d0/((hb/h)**2)))
	Ehautli=((Er-1.d0)/4.6d0)*((b/h)/dsqrt(w/h))
	Eeff=((Er+1.d0)/2.d0)+((Er-1.d0)/2.d0)*fonc*Eboitier-Ehautli 

C     *************** CALCUL DE LA LARGEUR DE LIGNE EQUIVALENTE ****************  

	if (rapp.GE.(1.d0/2.d0*pi)) then
		xx=h
	else
		xx=2*pi*w
	endif 
	We=w+(1.25d0*b/pi)*(1.d0+dlog(2*xx/b))

C     ************** CALCUL DE L'IMPEDANCE CARACTERISTIQUE EN BF ***************  

	P=270*(1.d0-dtanh(0.28d0+1.2d0*dsqrt(hb/h)))
	if (rapp.LE.1.d0) then
		dZcbf=(dZoI/(2*pi*dsqrt(Eeff)))*log((8.d0*h/We)+(We/(4.d0*h)))
  	else
		r=We/h
		dZcbf=(dZoI/dsqrt(Eeff))*(r+1.393d0+0.667d0*log(r+1.444d0))
	endif

C     ************** CORRIGE DE LA DERIVE EN FREQUENCE **************************  

	G=((dZcbf-5.d0)/60.d0)+0.04d0*dZcbf
	fp=dZcbf/(8*pi*1.d-7*h)
	Eef=Er-((Er-Eeff)/(1.d0+G*((f*1.D9)/fp)**2))

C     ************** CALCUL DE L'IMPEDANCE CARACTERISTIQUE **********************  

	if (rapp.LE.1.d0) then
		dZc=(dZoI/(2*pi*dsqrt(Eef)))*log((8.d0*h/We)+(We/(4.d0*h)))-P
  	else
		r=We/h
		delta=(0.48d0*dsqrt((We/h)-1))/(1.d0+(hb/h)**2)
		PH=P*(1.d0-dtanh(1.d0+delta))
		dZc=(dZoI/dsqrt(Eef))*(r+1.393d0+0.667d0*log(r+1.444d0))-PH
	endif

C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 
      END                                         

C     **********************************************      
C     *-----*     nouveau sous-programme     *-----* 
C     **********************************************      

	SUBROUTINE zccoplan (w,slot,h,Er,dZc,Eeff)

C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	IMPLICIT INTEGER (I)
   
      PARAMETER (pas=3.125)  
	
	cel=3.D8
	pi=4.D0*datan(1.D0)
	rap=h/w
	rapp=w/h

C     ************************ CALCUL DE EPSILON EFFECTIF  *******************  

	dk=w/(w+2*slot)

	term1=dtanh(1.75d0+(1.785d0*log(h/slot)))
	term2=(0.04d0-0.7d0*dk)*(dk*slot/h)
	term3=0.01d0*(1.d0-0.1d0*Er)*(0.25d0+dk)
	Eeff=((Er+1.d0)/2.d0)*(term1+term2+term3)

C     ************** CALCUL DE L'IMPEDANCE CARACTERISTIQUE  ********************  

	if (dk.LT.1.d0) then
		if (dk.GE.(dsqrt(2.d0)/2.d0)) then
		  fonc=(1.d0/pi)*log(2.d0*((1.d0+dsqrt(dk))/(1.d0-dsqrt(dk))))
		else	
			dkk=dsqrt(1.d0-(dk**2))
			fonc=pi/log(2.d0*((1.d0+dsqrt(dkk))/(1.d0-dsqrt(dkk))))
		endif 		
	else
		write(*,*)'erreur,vous avez � faire � 2 lignes coupl�s'
	endif
	dZc=(30.d0*pi)/(fonc*dsqrt(Eeff))

C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 
      END          



