



      
      PROGRAM BONsimple
     
C  ************************************************************************
C  �                                                                      �
C  �  *-*-*       MISE EN OEUVRE DU PROCESSUS ITERATIF POUR        *-*-*  �
C  �  *-*-*          LES CIRCUITS PLANAIRES MULTICOUCHES           *-*-*  �
C  �                                                                      �
C  �                      DEFINITION DES  ONDES:                          �
C  �                                                                      �
C  �         |           MILIEU (1): ONDES ZA1, ZB1          |            �
C  �         |           MILIEU (2): ONDES ZA2, ZB2          |            �
C  �         |           MILIEU (3): ONDES ZA3, ZB3          |            �
C  �         |           MILIEU (4): ONDES ZA4, ZB4          |            �
C  �                                                                      �
C  �   �   |           N"gongo Simplice Rufin.                     |  �   �
C  �   �   |           Ph.D Researches.                            |  �   �
C  �   �   |           ENSEEIHT-INPT                               |  �   �
C  �   �   |         All right reserved and protected by copyright |  �   �
C  �   �   |                                   |  �   �
C  �                                                                      �
C  ************************************************************************       

      IMPLICIT DOUBLEPRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER(n01=128,n02=128,DZero=0.d0,Cel=3.d8)
C     nn01 et nn02 nombre des pixels pour la source	 
	PARAMETER(nn01=6,nn02=6)

      DIMENSION ZB1mx(n01,n02),ZB2mx(n01,n02)													 
      DIMENSION ZB1nz(n01,n02),ZB2nz(n01,n02)
      DIMENSION ZA1mx(n01,n02),ZA2mx(n01,n02)
	DIMENSION ZA1nz(n01,n02),ZA2nz(n01,n02)

      DIMENSION ZA2mox(n01,n02),ZA1mox(n01,n02)
      DIMENSION ZA1noz(n01,n02),ZA2noz(n01,n02)
      DIMENSION ZB1x(n01,n02),ZB2x(n01,n02)
      DIMENSION ZB1z(n01,n02),ZB2z(n01,n02)

	DIMENSION ZBB1x(n01,n02),ZBB2x(n01,n02)
      DIMENSION ZBB1z(n01,n02),ZBB2z(n01,n02)
      
	DIMENSION ZA1te(n01,n02),ZA1th(n01,n02),ec(n01,n02)
	DIMENSION ZA2te(n01,n02),ZA2th(n01,n02)
	DIMENSION ZA3te(n01,n02),ZA3th(n01,n02)

	DIMENSION ZE1x(n01,n02),ZE2x(n01,n02)
      DIMENSION ZE1z(n01,n02),ZE2z(n01,n02)
      DIMENSION ZJ1x(n01,n02),ZJ2x(n01,n02)
      DIMENSION ZJ1z(n01,n02),ZJ2z(n01,n02),DH12s(n01,n02)
      DIMENSION DH1i(n01,n02),DH1m(n01,n02),DH1s(n01,n02) !DH1g(n01,n02)

      DIMENSION ZA3mox(n01,n02),ZA4mox(n01,n02)
	DIMENSION ZA3noz(n01,n02),ZA4noz(n01,n02)
	DIMENSION ZB3mx(n01,n02),ZB4mx(n01,n02),DH1ii(n01,n02)
      DIMENSION ZB3nz(n01,n02),ZB4nz(n01,n02)
      DIMENSION ZA3mx(n01,n02),ZA4mx(n01,n02)
      DIMENSION ZA3nz(n01,n02),ZA4nz(n01,n02),DHvar(n01,n02)

      DIMENSION ZB3x(n01,n02),ZB4x(n01,n02)
      DIMENSION ZB3z(n01,n02),ZB4z(n01,n02)
      DIMENSION ZA4te(n01,n02),ZA4th(n01,n02)

      DIMENSION ZE3x(n01,n02),ZE4x(n01,n02),DHs21(n01,n02)
      DIMENSION ZE3z(n01,n02),ZE4z(n01,n02),DHp(n01,n02)
      DIMENSION ZJ3x(n01,n02),ZJ4x(n01,n02),DH21s(n01,n02)
      DIMENSION ZJ3z(n01,n02),ZJ4z(n01,n02),via(n01,n02)
      DIMENSION DH2i(n01,n02),DH2m(n01,n02),DH2s(n01,n02)

	DIMENSION ZRefe2(n01,n02),ZRefh2(n01,n02)
	DIMENSION ZRefe1(n01,n02),ZRefh1(n01,n02)

	DIMENSION ZchainE11(n01,n02),ZchainE12(n01,n02)
	DIMENSION ZchainE21(n01,n02),ZchainE22(n01,n02)

	DIMENSION ZchainH11(n01,n02),ZchainH12(n01,n02)
	DIMENSION ZchainH21(n01,n02),ZchainH22(n01,n02)



C --- Ajouter apr�s les autres d�clarations de dimensions ---
      DIMENSION sigma_graphene(n01,n02)  ! Conductivit� du graph�ne
      DIMENSION Zg_matrix(n01,n02)        ! Imp�dance de surface du graph�ne
      INTEGER count_graphene              ! ? AJOUTER CETTE LIGNE



 

	CHARACTER*15 LouC
  	Zero=DCMPLX(DZero,DZero)                       
      Pi=4.D0*DATan(1.D0)

C	 ---------------------- Fin Declaration ---------





      
	CALL MENUPLAN(Nsource,Iparois,Isource,Ipolar,Ispost,NBItd,ITache,
     &	         Icapot,Freqdebut,Freqfin,freqpas)

	CALL FFTDON(a,b,v1,v2,v3,v4,Dmil1,Dmil2,Dmil3,Dmil4,w,s,
     &			LouC,epaisseurmetal,sigma)
	
      DZo1=120*Pi/DSQRT(Dmil1)
      DZo2=120*Pi/DSQRT(Dmil2)
      DZo3=120*Pi/DSQRT(Dmil3)
      DZo4=120*Pi/DSQRT(Dmil4)

	Dn1=DSQRT(DZo1/DZo2)
  		  
      Dn3=DSQRT(DZo3/DZo4)

      Dn12=(Dn1**2-1)/(Dn1**2+1)
      Dn21=2*Dn1/(Dn1**2+1)
      Dn34=(Dn3**2-1)/(Dn3**2+1)
      Dn43=2*Dn3/(Dn3**2+1)

	DZo12=DZo1*DZo2/(DZo1+DZo2)
	Dnn1=DZo12/DZo1
	Dnn2=DZo12/DZo2
	Dnn3=DZo12/DSQRT(DZo1*DZo2)

	DZo34=DZo3*DZo4/(DZo3+DZo4)
	Dnn13=DZo34/DZo3
	Dnn23=DZo34/DZo4
	Dnn33=DZo34/DSQRT(DZo3*DZo4)

	DPixelx=a/n01
	DPixely=b/n02

C	 excitation de la source (milieu 1, milieu 2, milieu 1 et 2)
	If(ISpost.Eq.1)Then		
		Ipol1=1 
		Ipol2=0
	Else
	If(ISpost.Eq.2)Then		
		Ipol1=0 
		Ipol2=1							
	Else
	If(ISpost.Eq.3)Then		
		Ipol1=1 
		Ipol2=1	
	Endif
	Endif
	Endif

	Dnom12=1.d0+Ipol1*Dnn1+Ipol2*Dnn2

 	Dnom34=1.d0+Ipol1*Dnn13+Ipol2*Dnn23

C	 ****************** Resultats **************************
      OPEN(30,File='Impedant.dat',Status='Unknown')
      OPEN(31,File='DScat.dat',Status='Unknown')
      OPEN(32,File='Phase.dat',Status='Unknown')
 	OPEN(33,File='RO3SS.dat',Status='Unknown')
	OPEN(34,File='Yadmit.dat',Status='Unknown')


      OPEN(300,File='Impe3dd1z.dat',Status='Unknown')
      OPEN(310,File='Sca3ttz.dat',Status='Unknown')
      OPEN(320,File='Phas3eez.dat',Status='Unknown')
	OPEN(330,File='RO3Ssz.dat',Status='Unknown')

	OPEN(21,File='Courantx.dat',Status='Unknown')
	OPEN(22,File='Couranty.dat',Status='Unknown')
	OPEN(23,File='Champ1x.dat',Status='Unknown')
	OPEN(24,File='Champ1y.dat',Status='Unknown')
	OPEN(25,File='Champ2x.dat',Status='Unknown')
	OPEN(26,File='Champ2y.dat',Status='Unknown')
	open(27,file='y.dat',status='unknown')

	OPEN(121,File='Courantxx.dat',Status='Unknown')
	OPEN(122,File='Courantyy.dat',Status='Unknown')
	OPEN(123,File='Champ3x.dat',Status='Unknown')
	OPEN(124,File='Champ3y.dat',Status='Unknown')
	OPEN(125,File='Champ4x.dat',Status='Unknown')
	OPEN(126,File='Champ4y.dat',Status='Unknown')
			
		write(21,*)'%',Freqdebut,'Courantx'
	    write(22,*)'%',Freqdebut,'Couranty'
	    write(23,*)'%',Freqdebut,'Champ1x'
		write(24,*)'%',Freqdebut,'Champ1y'
	    write(25,*)'%',Freqdebut,'Champ2x'
	    write(26,*)'%',Freqdebut,'Champ2y'

		write(121,*)'%',Freqdebut,' Courantx',NBItd
	    write(122,*)'%',Freqdebut,' Couranty',NBItd
	    write(123,*)'%',Freqdebut,' Champ3x',NBItd
		write(124,*)'%',Freqdebut,' Champ3y',NBItd
	    write(125,*)'%',Freqdebut,' Champ4x',NBItd
	    write(126,*)'%',Freqdebut,' Champ4y',NBItd
		
		write(30,*)'Freq',' ReZ11',' ImZ11',' ReZ12',' ImZ12',' ',
     &				NBItd,'it ',Freqdebut,'GHz'
		write(31,*)'freq',' S11',' S12',' ',NBItd,'it ',Freqdebut,
     &				'GHz'
		write(32,*)'freq',' Ph11',' Ph12',' ',NBItd,'it ',Freqdebut,
     &				'GHz'
		write(34,*)'Freq',' ReY11',' ImY11',' ReY12',' ImY12',' ',
     &				NBItd,'it ',Freqdebut,'GHz'
         
	    write(300,*)Freqdebut,' Z11',' ',' Z12'
	    write(310,*)Freqdebut,' S11',' ',' S12'
	    write(320,*)Freqdebut,' Ph11',' ',' Ph12'


      OPEN(1000,STATUS='OLD',FILE='tlmm.dat')
      OPEN(2000,STATUS='OLD',FILE='tlmd.dat')
      OPEN(3000,STATUS='OLD',FILE='tlms1.dat')
      OPEN(4000,STATUS='OLD',FILE='tlms2.dat')
!	OPEN(50000,STATUS='OLD',FILE='tlmg.dat') !radhoine_graphene


C --- Ajouter apr�s la lecture des autres fichiers ---
      OPEN(5000,STATUS='OLD',FILE='graphene.dat')


	
	OPEN(10000,FILE='test')	
		

		Read(1000,*)((DH1m(m,n),m=1,n01),n=1,n02)   
		Read(2000,*)((DH1i(m,n),m=1,n01),n=1,n02)
		Read(3000,*)((DH1s(m,n),m=1,n01),n=1,n02)
		Read(4000,*)((DH12s(m,n),m=1,n01),n=1,n02)
!		Read(5000,*)((DH1g(m,n),m=1,n01),n=1,n02)  !radhoine
		Read(5000,*)((sigma_graphene(m,n),m=1,n01),n=1,n02)


	Close(1000)
      Close(2000)
	Close(3000)
	Close(4000)
	Close(5000)	!radhoine

      
      

	CALL horaire (itmpyear1,itmpmonth1,itmpday1,dj1,
     &			itmphour1,itmpminute1,itmpsecond1,itmphund1)

      write(*,*)'Impedance interne de la source: ',DZo12

C	 ---------------	D�but de la boucle de fr�quence  -----------
	
       Do 41 Freq=Freqdebut,Freqfin,Freqpas  

    		ZEtot1=Zero
		ZJtot1=Zero
		ZZJtot1=Zero
		ZEtot2=Zero
		ZJtot2=Zero
		ZZJtot2=Zero
                 
    		ZEtot1z=Zero
		ZJtot1z=Zero
		ZZJtot1z=Zero
		ZEtot2z=Zero
		ZJtot2z=Zero
		ZZJtot2z=Zero

		write(*,*)'Frequence=',Freq

		Dzc=50.d0
		write(*,*)'Zc=',DZc

C =========================================================================
C ??? AJOUTER LE CALCUL DE L'IMP�DANCE DU GRAPH�NE ICI ???
C =========================================================================

C --- Calcul de l'imp�dance de surface du graph�ne ---
C --- Calcul de l'imp�dance de surface du graph�ne ---
C --- Calcul de l'imp�dance de surface du graph�ne ---
      count_graphene = 0
      
      DO m=1,n01
        DO n=1,n02
          If(sigma_graphene(m,n).GT.1.d-6) Then
            Zg_matrix(m,n) = 1.0d0 / sigma_graphene(m,n)
            count_graphene = count_graphene + 1
          Else
            Zg_matrix(m,n) = 1.0d10  ! Tr�s haute imp�dance si conductivit� nulle
          Endif
        END DO
      END DO

      write(*,*) 'Graph�ne int�gr�: ', count_graphene, 
     &           ' pixels actifs'
C =========================================================================

C        ************************************************************* 
C        �                                                           �
C        � &&--&& DEFINITION SPACIALE DE L'ONDE INCIDENTE  ZA &&--&& �                 
C        �     &-&  ZA1 pour le milieu (1) suivant Ox et Oz  &-&     �
C        �     &-&  ZA2 pour le milieu (2) suivant Ox et Oz  &-&     �
C        �     &-&  ZA3 pour le milieu (3) suivant Ox et Oz  &-&     �
C        �     &-&  ZA4 pour le milieu (4) suivant Ox et Oz  &-&     �   
C        �                                                           �
C        *************************************************************
C		--------------- d�finition des ondes d'excitation ----------

	
         CALL FFTSOU(n01,n02,IPolar,Dnom12,ISpost,ZA1mox,ZA2mox,
     &                                ZA1noz,ZA2noz)

             
c        CALL FFTSOU(n01,n02,IPolar,Dnom34,ISpost,ZA3mox,ZA4mox,
c     &                                                ZA3noz,ZA4noz)
C		-------- Restriction de l'onde d'excitation, 
C					pond�r�e par le milieu,� la source --------------
 	 
		DO 2 m=1,n01
          DO 2 n=1,n02       
			If(Nsource.EQ.1)Then			        
c				If(Isource.EQ.1) Then				          
C                 *--*--* Suivant Ox *--*--*                                           
                     ZA1mx(m,n)=ZA1mox(m,n)*DH1s(m,n)/DSQRT(DZo1)
                     ZA2mx(m,n)=ZA2mox(m,n)*DH1s(m,n)/DSQRT(DZo2)
				   ZA3mox(m,n)=Zero
				   ZA4mox(m,n)=Zero
C                 *--*--* Suivant Oz *--*--*                               
                     ZA1nz(m,n)=ZA1noz(m,n)*DH1s(m,n)/DSQRT(DZo1)
                     ZA2nz(m,n)=ZA2noz(m,n)*DH1s(m,n)/DSQRT(DZo2)
c				   ZA3noz(m,n)=Zero
c				   ZA4noz(m,n)=Zero
c				Else
C				*--*--* Suivant Ox *--*--* 
c				   ZA1mox(m,n)=Zero
c				   ZA2mox(m,n)=Zero	   
c                     ZA3mx(m,n)=ZA3mox(m,n)*DH2s(m,n)/DSQRT(DZo3)
c                     ZA4mx(m,n)=ZA4mox(m,n)*DH2s(m,n)/DSQRT(DZo4)
C                 *--*--* Suivant Oz *--*--*
c				   ZA1noz(m,n)=Zero
c				   ZA2noz(m,n)=Zero
c                     ZA3nz(m,n)=ZA3noz(m,n)*DH2s(m,n)/DSQRT(DZo3)
c                     ZA4nz(m,n)=ZA4noz(m,n)*DH2s(m,n)/DSQRT(DZo4)
c				Endif
				If(FreQ.EQ.Freqdebut)DH1m(m,n)=DH1m(m,n)+DH12s(m,n)
c     &               DH1i(m,n)+DH1s(m,n)			    
c				If(FreQ.EQ.Freqdebut)DH2m(m,n)=DH2m(m,n)+DH21s(m,n)    
			Else
c				If(Isource.EQ.1) Then				          
C                 *--*--* Suivant Ox *--*--*                                           
					ZA1mx(m,n)=ZA1mox(m,n)*DH1s(m,n)/DSQRT(DZo1)
					ZA2mx(m,n)=ZA2mox(m,n)*DH1s(m,n)/DSQRT(DZo2)
c					ZA3mox(m,n)=Zero
c					ZA4mox(m,n)=Zero
C                 *--*--* Suivant Oz *--*--*                               
					ZA1nz(m,n)=ZA1noz(m,n)*DH1s(m,n)/DSQRT(DZo1)
					ZA2nz(m,n)=ZA2noz(m,n)*DH1s(m,n)/DSQRT(DZo2)
c					ZA3noz(m,n)=Zero
c					ZA4noz(m,n)=Zero
c				Else 
c					ZA1mox(m,n)=Zero
c					ZA2mox(m,n)=Zero  
c					ZA3mx(m,n)=ZA3mox(m,n)*DH2s(m,n)/DSQRT(DZo3)
c					ZA4mx(m,n)=ZA4mox(m,n)*DH2s(m,n)/DSQRT(DZo4)					
C                 *--*--* Suivant Oz *--*--*
c					ZA1noz(m,n)=Zero
c					ZA2noz(m,n)=Zero
c					ZA3nz(m,n)=ZA3noz(m,n)*DH2s(m,n)/DSQRT(DZo3)
c					ZA4nz(m,n)=ZA4noz(m,n)*DH2s(m,n)/DSQRT(DZo4)				
c				Endif
			If(FreQ.EQ.Freqdebut)DH1i(m,n)=DH1i(m,n)+DABS(DH12s(m,n))    
c			If(FreQ.EQ.Freqdebut)DH2i(m,n)=DH2i(m,n)+DABS(DH21s(m,n))    
			Endif
	

C       ******************************************************************** 
C       �                                                                  �
C       �  CALCUL DES OPERATEURS DU DOMAINE SPECTRAL:Operateur Ref et Scat �
C       �                                                                  � 
C       ******************************************************************** 

	 		CALL Reflexion(m,n,a,b,v1,v2,n01,n02,ICapot,DZo1,DZo2,
     &					Freq,Dmil1,Dmil2,ZRefe1,ZRefh1,ZRefe2,ZRefh2)

							   
c	        CALL MatScatt(m,n,Freq,a,v2,v3,b,n01,n02,DZo2,DZo3,
c     &                     Dmil2,Dmil3,ZchainE11,ZchainE12,
c     &					 ZchainE21,ZchainE22,ZchainH11,ZchainH12,
c     &					 ZchainH21,ZchainH22)
c
2		Continue  
	   
C	   ***** Calcul des pertes m�talliques dans le plan principal: interface 1-->2 *****
		
		CALL pertes (dZo1,dZo2,epaisseurmetal,sigma,freq,
     &					sm11,sm12,sm21,sm22)
	sm11=-1
	sm12=0
	sm21=0
	sm22=-1
	
        
C		**********	D�but de la boucle des it�rations  **********
      do 127 l=1,Nbitd

	

C       ********************************************************************
C       �                                                                  �
C       � TRANSFORMEE DE FOURIER INVERSE (EN MODE) DE L'ONDE REFLECHIE ZB  � 
C       �                                                                  �
C       ******************************************************************** 
														
			CALL MATRICE_DE_MODE(n01,n02,a,b,IParois,ZA1mx,ZA2mx,
     &                             ZA1nz,ZA2nz,ZA1te,ZA2te,ZA1th,ZA2th)
    
              CALL MAT_MODE_INV(n01,n02,a,b,IParois,ZA1te,ZA1th,
     &						  ZA2te,ZA2th,ZRefe1,ZRefh1,ZRefe2,ZRefh2,
     &                          ZB1mx,ZB1nz,ZB2mx,ZB2nz)
       
C       ********************************************************************
C       �																	 �
C       �   &-&  CONTINUITE SUR LA SURFACE DE DISCONTINUITE   &-&			 � 
C       �       &-&              ENTRE Er1/Er2             &-&			 �
C       �																	 �
C       ********************************************************************

 			pcentx=50
			pcenty=100



                                                                     
	        CALL SCATERRING_MATR1(n01,n02,IPolar,ISpost,Dn12,Dn21,
     &							Ipol1,Ipol2,Dnn1,Dnn2,Dnn3,Dnom12,DHp,
     &							DH1i,DH1m,DH1s,via,ZB1mx,ZB2mx,
     &                            ZB1nz,ZB2nz,ZA1mox,ZA2mox,
     &							ZA1noz,ZA2noz,ZB1x,ZB2x,ZB1z,ZB2z,
     &						   sm11,sm12,sm21,sm22,freq,pcentx,pcenty,
     &						    DZo1,DZo2,a,b,Zg_matrix)


C       ******************************************************************** 
C	  �                                                                  �
C	  �	  *-*-*    DETERMINATION DES CHAMPS TRANSVERSES         *-*-*    �
C	  �			                                                         �
C	  �			         | CHAMP ELECTRIQUE TANGENTIEL:   [Et]     |     �
C	  �			         | CHAMP MAGNETIQUE TANGENTIEL:   [J]      |     �
C	  �			         | CHAMP ELECTRIQUE TANGENTIEL:   [Et]     |     �
C	  �                                                                  �
C       �       &-&  A L INTERFACE ENTRE Er1/Er2             &-&           �
C	  �                                                                  �
C       ********************************************************************

			CALL FFTchmc(Nsource,DZo1,DZo2,n01,n02,Ipolar,ISpost,
     &					  DH1s,DH12s,ZEtot1,ZJtot1,ZZJtot1,
     &					  ZEtot1z,ZJtot1z,ZZJtot1z,
     &                      ZB1x,ZB2x,ZB1z,ZB2z,
     &					  ZA1mox,ZA2mox,ZA1noz,ZA2noz,
     &					  ZA1mx,ZA2mx,ZA1nz,ZA2nz,
     &					  ZB1mx,ZB2mx,ZB1nz,ZB2nz,
     &					  ZE1x,ZE2x,ZE1z,ZE2z,ZJ1x,ZJ2x,ZJ1z,ZJ2z)
	  
	 

C       ******************************************************************** 
C       �	                                                                 �
C       �                                                                  �
C       �  *-*-*   DETERMINATION DES PARAMETRES DE DIFFTRACTION   *-*-*    �  
C       �                                                                  �
C       �         |               MATRICE IMPEDANCE:	[Z]        |         �
C       �         |              MATRICE ADMITTANCE:	[Y]        |         �
C       �         |          MATRICE DE DIFFRACTION:	[S]        |         �
C       �                                                                  �  
C       ********************************************************************
			If(ITache.EQ.1)Then
c				If(Isource.EQ.1)Then
			
					CALL FFTSZY1(Nsource,DZc,l,ITache,IPolar,
     &							ZEtot1,ZJtot1,ZZJtot1,
     &							 ZEtot1z,ZJtot1z,ZZJtot1z,
     &							 DRZ11,DIZ11,DRZ12,DIZ12,			
     &							 DS11,DS12,DPh11,DPh12,
     &							 DRZ11z,DIZ11z,DRZ12z,DIZ12z,			
     &							 DS11z,DS12z,DPh11z,DPh12z,
     &							 DRY11,DIY11,DRY12,DIY12)
c				Else	
c				If(Isource.EQ.2)Then
c
c					CALL FFTSZY1(Nsource,DZc,l,ITache,IPolar,
c     &							 ZEtot2,ZJtot2,ZZJtot2,
c     &							 ZEtot2z,ZJtot2z,ZZJtot2z,
c     &							 DRZ11,DIZ11,DRZ12,DIZ12,			
c     &							 DS11,DS12,DPh11,DPh12,
c     &							 DRZ11z,DIZ11z,DRZ12z,DIZ12z,			
c     &							 DS11z,DS12z,DPh11z,DPh12z,
c     &							 DRY11,DIY11,DRY12,DIY12)
c	
c				Endif
c				Endif			
				write(30,28)DRZ11,DIZ11,DRZ12,DIZ12
				write(31,29)DS11,DS12
  				write(32,29)DPh11,DPh12
				write(34,28)DRY11,DIY11,DRY12,DIY12
				write(300,28)DRZ11z,DIZ11z,DRZ12z,DIZ12z
				write(310,29)DS11z,DS12z
  				write(320,29)DPh11z,DPh12z
			Endif	
 
      
	  
127      Continue
      	 
C		**********	Fin de la boucle des it�rations  **********

C       ******************************************************************** 
C       �                                                                  �
C       �                                                                  �
C       �  *-*-*   DETERMINATION DES PARAMETRES DE DIFFTRACTION   *-*-*    � 
C       �                                                                  �
C       �         |               MATRICE IMPEDANCE:[Z]        |           �
C       �         |              MATRICE ADMITTANCE:[Y]        |           �
C       �         |          MATRICE DE DIFFRACTION:[S]        |           �
C       �                                                                  �
C       ********************************************************************
		If(ITache.NE.1)Then
c			If(Isource.EQ.1)Then
c
				CALL FFTSZY2(Nsource,DZc,ITache,IPolar,
     &						 ZEtot1,ZJtot1,ZZJtot1,
     &						 ZEtot1z,ZJtot1z,ZZJtot1z,
     &						 DRZ11,DIZ11,DRZ12,DIZ12,			
     &						 DS11,DS12,DPh11,DPh12,DRZ11z,DIZ11z,
     &						 DRZ12z,DIZ12z,DS11z,DS12z,DPh11z,DPh12z,
     &		DRY11,DIY11,DRY12,DIY12,a,b,DPixelx,DPixely,nn01,nn02)
c			Else	
c			If(Isource.EQ.2)Then
c				CALL FFTSZY2(Nsource,DZc,ITache,IPolar,
c     &						 ZEtot2,ZJtot2,ZZJtot2,
c     &						 ZEtot2z,ZJtot2z,ZZJtot2z,
c     &						 DRZ11,DIZ11,DRZ12,DIZ12,			
c     &						 DS11,DS12,DPh11,DPh12,
c     &						 DRZ11z,DIZ11z,DRZ12z,DIZ12z,			
c     &						 DS11z,DS12z,DPh11z,DPh12z,
c     &						 DRY11,DIY11,DRY12,DIY12)
c			Endif
c			Endif		
			write(30,26)Freq,DRZ11,DIZ11,DRZ12,DIZ12
			write(31,25)Freq,DS11,DS12
  			write(32,25)Freq,DPh11,DPh12
			write(34,26)Freq,DRY11,DIY11,DRY12,DIY12
			write(300,26)Freq,DRZ11z,DIZ11z,DRZ12z,DIZ12z
			write(310,25)Freq,DS11z,DS12z
  			write(320,25)Freq,DPh11z,DPh12z
		Endif

  41 	CONTINUE

C	 **********	Fin de la boucle en fr�quence  **********

	Close(30)
	Close(31)
	Close(32)
	Close(34)
	Close(300)
	Close(310)
	Close(320)
	write (*,*) cel
	

	CALL horaire (itmpyear2,itmpmonth2,itmpday2,dj2,
     &			  itmphour2,itmpminute2,itmpsecond2,itmphund2)

	CALL tpsexec (itmpyear1,itmpmonth1,itmpday1,dj1,
     &			  itmphour1,itmpminute1,itmpsecond1,
     &			  itmpyear2,itmpmonth2,itmpday2,dj2,
     &		      itmphour2,itmpminute2,itmpsecond2)

C      --------- Les resultats relatifs aux champs ----

      write(21,27)((CDABS(ZJ1x(m,n)),m=1,n01),n=1,n02)    
      write(22,27)((CDABS(ZJ1z(m,n)),m=1,n01),n=1,n02)  

      write(23,27)((CDABS(ZE1x(m,n)),m=1,n01),n=1,n02)    
      write(24,27)((CDABS(ZE1z(m,n)),m=1,n01),n=1,n02)  

      write(25,27)((CDABS(ZE2x(m,n)),m=1,n01),n=1,n02)    
      write(26,27)((CDABS(ZE2z(m,n)),m=1,n01),n=1,n02)  

      write(121,27)((CDABS(ZJ3x(m,n)),m=1,n01),n=1,n02)    
      write(122,27)((CDABS(ZJ3z(m,n)),m=1,n01),n=1,n02)  

      write(123,27)((CDABS(ZE3x(m,n)),m=1,n01),n=1,n02)    
      write(124,27)((CDABS(ZE3z(m,n)),m=1,n01),n=1,n02)  

      write(125,27)((CDABS(ZE4x(m,n)),m=1,n01),n=1,n02)    
      write(126,27)((CDABS(ZE4z(m,n)),m=1,n01),n=1,n02)  

 27   Format(128(f14.6,1x))
 28   Format(4(f12.6,1x))
 29   Format(2(f12.6,1x))
 26   Format(5(f12.6,1x))
 25   Format(3(f12.6,1x))

C       ******************************************************************** 
C       �																	 �
C       �																	 �
C       �  *-*-*   DETERMINATION DU DIAGRAMME DE RAYONNEMENT   *-*-*		 �
		 
c			CALL RAY1(a,b,n01,n02,Freq,IParois,ZE1x,ZE1z,ZE2x,ZE2z)

C	  �																	 �
C       *******************************************************************  

                                                                         


137   END    