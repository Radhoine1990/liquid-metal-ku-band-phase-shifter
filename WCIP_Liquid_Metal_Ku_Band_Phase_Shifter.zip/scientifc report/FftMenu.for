C		liste des programmes:MENUPLAN,MENUcoupl,
C							 FFTSZY1,FFTSZY2,FFTZYS11,FFTZYS22
C					function:tetha(x,y)

      SUBROUTINE MENUPLAN(Nsource,Iparois,Isource,Ipolar,Ispost,NBIt,
     &					ITache,Icapot,Freqdebut,Freqfin,freqpas)
    
C  ************************************************************************ 
C  �                                                                      �
C  �  *-*-*       MISE EN OEUVRE DU PROCESSUS ITERATIF POUR        *-*-*  �
C  �  *-*-*          LES CIRCUITS PLANAIRES MULTICOUCHES           *-*-*  �
C  �                                                                      �
C  �                      DEFINITION DES  ONDES:                          �
C  �                                                                      �
C  �         |           MILIEU (1): ONDES ZA1, ZB1          |            �
C  �         |           MILIEU (2): ONDES ZA2, ZB2          |            �
C  �         |           MILIEU (3): ONDES ZA3, ZB3          |            �
C  �         |           MILIEU (4): ONDES ZA4, ZB4          |            �
C  �                                                                      �
C  �   �   |           N"gongo Simplice Rufin.                     |  �   �
C  �   �   |           Ph.D Reseaches.                             |  �   �
C  �   �   |           ENSEEIHT-INPT                               |  �   �
C  �   �   |           All right reserved and protect by copyright |  �   �
C  �   �   |           Date: Juin  1998                            |  �   �
C  �                                                                      �
C  ************************************************************************       

      IMPLICIT DOUBLEPRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
C	CHARACTER*15 Hfil1,HFil2,Hfil3 

C	 &&&& ===========  Presentation du programme =========== &&&&&

      write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(/t15,a,\)')'�                                         �'
      write(*,'(/t15,a,\)')'�   RAPID METHOD FOR ARBITRARY SINGLE,    �'
      write(*,'(/t15,a,\)')'�  MULTILAYERED AND STACKED MICROSTRIP    �'
	write(*,'(/t15,a,\)')'�  STRUCTURES USING AN INTERATIVE TECHN   �'
	write(*,'(/t15,a,\)')'�  BASED ON THE WAVE CONCEPT AND THE      �'
	write(*,'(/t15,a,\)')'�		      MODAL FFT ALGORITHM           �'
      write(*,'(/t15,a,\)')'� ================= && =================  �'
      write(*,'(/t15,a,\)')'�                                         �'
	write(*,'(/t15,a,\)')'�			         AUTHORS:	  	        �'  
	write(*,'(/t15,a,\)')'�                                         �'          
    	write(*,'(/t15,a,\)')'�			zouaoui                 		�'
    	write(*,'(/t15,a,\)')'�		    				                �'
	write(*,'(/t15,a,\)')'�		    					            �'
      write(*,'(/t15,a,\)')'� ================= && =================	�'
      write(*,'(/t15,a,\)')'�											�'
      write(*,'(/t15,a,\)')'�          All rigths reserved			�'
      write(*,'(/t15,a,\)')'�											�'
      write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(///t15,a,\)')'             '      
      pause            
	           
      write(*,'(/t15,a,\)')'Donnez la nature de(des)source(s)'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Electrique:       (1)' 
      write(*,'(/t15,a,\)')'Magnetique:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)Nsource
      write(*,'(/t15,a,\)')

      write(*,'(/t15,a,\)')'Donnez la nature des parois laterales'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Electriques:       (1)' 
      write(*,'(/t15,a,\)')'Magnetiques:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)IParois                                 
	
	write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��        POSITION DE LA SOURCE          ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(///t15,a,\)')'             '      
      write(*,'(/t15,a,\)')'Donnez la position de la source:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'A la 1ere discontinuite:       (1)' 
      write(*,'(/t15,a,\)')'A la 2eme discontinuite:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)ISource                                

      write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��      POLARISATION DE LA SOURCE        ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'*******************************************'
      write(*,'(///t15,a,\)')'             '      
      write(*,'(/t15,a,\)')'Donnez la polarisation de la source:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Suivant   (ox):            (1)' 
      write(*,'(/t15,a,\)')'Suivant   (oz):            (2)' 
      write(*,'(/t15,a,\)')'Suivant (ox) et (oz):      (3)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)IPolar      
	                	      
	write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Donnez la position de la source:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'          En Haut:(1)' 
      write(*,'(/t15,a,\)')'          En Bas :(2)'
      write(*,'(/t15,a,\)')'En Haut et en Bas:(3)'
      write(*,'(///t15,a,\)')'             '      
      Read(*,*)ISpost                   

C                         *-* Fin *-*       

      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Nombre Iterations'          
      write(*,'(///t15,a,\)')'             '      
      Read(*,*)NbIt

      write(*,'(/t15,a,\)')'Donnez la tache a effectuer:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Etude de convergence:       (1)' 
      write(*,'(/t15,a,\)')'Admittance par la frequence:(2)' 
      write(*,'(/t15,a,\)')'             '      
      Read(*,*)ITache                   
 
      write(*,'(/t15,a,\)')'Presence du Capot superieur?'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Avec Capot Superieur:       (1)' 
      write(*,'(/t15,a,\)')'Sans Capot Superieur:       (2)' 
      write(*,'(/t15,a,\)')'             '      
      Read(*,*)ICapot                   
      
      If(ITache.EQ.1) Then                        
		write(*,'(///t15,a,\)')'             '             
          write(*,'(/t15,a,\)')'Donnez la Frequence en GHz:'
          write(*,'(/t15,a,\)')'             '       
          Read(*,*)Freqdebut
          Freqfin=Freqdebut 
          Freqpas=1.d-16
      else                                                
          write(*,'(///t15,a,\)')'             '      
          write(*,'(/t15,a,\)')'Donnez la bande de Frequence en GHz:'
          write(*,'(/t15,a,\)') 
          Read(*,*)Freqdebut   
          write(*,'(/t15,a,\)')
          Read(*,*)Freqfin                                          
             
          write(*,'(/t15,a,\)')'Donnez le pas de la Frequence:'
          write(*,'(/t15,a,\)')
          Read(*,*)Freqpas 
          write(*,'(/t15,a,\)')
      Endif 
          
     	END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 *************************** 
						 
      SUBROUTINE MENUcoupl(Nsource,Iparois,Isource1,Isource2,
     &							  	        Ipolar1,Ipolar2,
     &			 							Ispost1,Ispost2,
     &										    NBIt,ITache,
     &									   Icapot,Freqdebut,
     &									    Freqfin,freqpas)

C  ************************************************************************ 
C  �                                                                      �
C  �  *-*-*       MISE EN OEUVRE DU PROCESSUS ITERATIF POUR        *-*-*  �
C  �  *-*-*          LES CIRCUITS PLANAIRES MULTICOUCHES           *-*-*  �
C  �                                                                      �
C  �                      DEFINITION DES  ONDES:                          �
C  �                                                                      �
C  �         |           MILIEU (1): ONDES ZA1, ZB1          |            �
C  �         |           MILIEU (2): ONDES ZA2, ZB2          |            �
C  �         |           MILIEU (3): ONDES ZA3, ZB3          |            �
C  �         |           MILIEU (4): ONDES ZA4, ZB4          |            �
C  �                                                                      �
C  �   �   |           N"gongo Simplice Rufin.                     |  �   �
C  �   �   |           Ph.D Reseaches.                             |  �   �
C  �   �   |           ENSEEIHT-INPT                               |  �   �
C  �   �   |           All right reserved and protect by copyright |  �   �
C  �   �   |           Date: Juin  1998                            |  �   �
C  �                                                                      �
C  ************************************************************************
  
      IMPLICIT DOUBLEPRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
C	CHARACTER*15 Hfil1,HFil2,Hfil3 

      write(*,'(/t15,a,\)')'�����������������������������������������Ŀ'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��  RAPID METHOD FOR ARBITRARY MICROSTRIP��'			.
      write(*,'(/t15,a,\)')'��   STRUCTURES USING THE W.I.C.P WITH   ��' 
      write(*,'(/t15,a,\)')'��           THE FFT ALGORITHM           ��'
      write(*,'(/t15,a,\)')'�� ================= && ================ ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'��                                       ��'
	write(*,'(/t15,a,\)')'�� == SOURCE COUPLING IN THE CIRCUIT === ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'�� ================= && ================ ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'��  N"gongo Simplice   PhD Dissertation  ��'
      write(*,'(/t15,a,\)')'��    Labo Electronique. ENSEEHIT-INPT   ��'
      write(*,'(/t15,a,\)')'��        &&& ====== && ====== &&&       ��'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'�������������������������������������������'
      write(*,'(///t15,a,\)')'             '      
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')
      pause                       

      write(*,'(/t15,a,\)')'Donnez la nature de(des)source(s)'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Electrique:       (1)' 
      write(*,'(/t15,a,\)')'Magnetique:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)Nsource
      write(*,'(/t15,a,\)')

      write(*,'(/t15,a,\)')'Donnez la nature des parois laterales'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Electriques:       (1)' 
      write(*,'(/t15,a,\)')'Magnetiques:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)IParois                                             

  	write(*,'(/t15,a,\)')'�����������������������������������������Ŀ'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��        POSITION DE LA SOURCE          ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'�������������������������������������������'
      write(*,'(///t15,a,\)')'             '      

      write(*,'(/t15,a,\)')'Donnez la position de la source (1)'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'A la 1ere discontinuite:       (1)' 
      write(*,'(/t15,a,\)')'A la 2eme discontinuite:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)ISource1              

      write(*,'(/t15,a,\)')'Donnez la position de la source (2)'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'A la 1ere discontinuite:       (1)' 
      write(*,'(/t15,a,\)')'A la 2eme discontinuite:       (2)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)ISource2  

      write(*,'(/t15,a,\)')'�����������������������������������������Ŀ'
      write(*,'(/t15,a,\)')'��                                       ��'
      write(*,'(/t15,a,\)')'��     POLARISATION  DE LA SOURCE        ��'
      write(*,'(/t15,a,\)')'��                                       ��'      
      write(*,'(/t15,a,\)')'�������������������������������������������'
      write(*,'(///t15,a,\)')'             '      

      write(*,'(/t15,a,\)')'Donnez la polarisation de la source 1:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Suivant   (ox):            (1)' 
      write(*,'(/t15,a,\)')'Suivant   (oz):            (2)' 
      write(*,'(/t15,a,\)')'Suivant (ox) et (oz):      (3)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)IPolar1
	
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Donnez la position de la source 1:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'          En Haut:(1)' 
      write(*,'(/t15,a,\)')'          En Bas :(2)'
      write(*,'(/t15,a,\)')'En Haut et en Bas:(3)'
      write(*,'(///t15,a,\)')'             '      
      Read(*,*)ISpost1                   

      write(*,'(/t15,a,\)')'Donnez la polarisation de la source 2:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Suivant   (ox):            (1)' 
      write(*,'(/t15,a,\)')'Suivant   (oz):            (2)' 
      write(*,'(/t15,a,\)')'Suivant (ox) et (oz):      (3)' 
      write(*,'(///t15,a,\)')'             '      
      read(*,*)IPolar2
	
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Donnez la position de la source 2:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'          En Haut:(1)' 
      write(*,'(/t15,a,\)')'          En Bas :(2)'
      write(*,'(/t15,a,\)')'En Haut et en Bas:(3)'
      write(*,'(///t15,a,\)')'             '      
      Read(*,*)ISpost2   

C                        *-* Fin *-*       

      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Nombre Iterations'          
      write(*,'(///t15,a,\)')'             '      
      Read(*,*)NbIt

      write(*,'(/t15,a,\)')'Donnez la tache a effectuer:'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Etude de convergence:       (1)' 
      write(*,'(/t15,a,\)')'Admittance par la frequence:(2)' 
      write(*,'(/t15,a,\)')'             '      
      Read(*,*)ITache                   
 
      write(*,'(/t15,a,\)')'Presence du Capot superieur?'
      write(*,'(/t15,a,\)')
      write(*,'(/t15,a,\)')'Avec Capot Superieur:       (1)' 
      write(*,'(/t15,a,\)')'Sans Capot Superieur:       (2)' 
      write(*,'(/t15,a,\)')'             '      
      Read(*,*)ICapot                   
      
      If(ITache.EQ.1) Then                        
		write(*,'(///t15,a,\)')'             '             
          write(*,'(/t15,a,\)')'Donnez la Frequence en GHz:'
          write(*,'(/t15,a,\)')'             '       
          Read(*,*)Freqdebut
          Freqfin=Freqdebut 
          Freqpas=1.d-16
      else                                                
          write(*,'(///t15,a,\)')'             '      
          write(*,'(/t15,a,\)')'Donnez la bande de Frequence en GHz:'
          write(*,'(/t15,a,\)') 
          Read(*,*)Freqdebut   
          write(*,'(/t15,a,\)')
          Read(*,*)Freqfin                                          
             
          write(*,'(/t15,a,\)')'Donnez le pas de la Frequence:'
          write(*,'(/t15,a,\)')
          Read(*,*)Freqpas 
          write(*,'(/t15,a,\)')
      Endif 

	END
	      