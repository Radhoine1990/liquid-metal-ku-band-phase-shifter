C	 *******************************
C	 �    NOUVEAU SOUS-PROGRAMME   �
C	 � COHEN Ludovic (Decembre2000)�
C	 �		Pertes metaliques	   �
C	 *******************************

	SUBROUTINE pertes (dZoI,dZoII,epaisseurmetal,sigma,f,
     &					sm11,sm12,sm21,sm22)						
							
C     ************************  DECLARATION DES VARIABLES  ************************    

      IMPLICIT DOUBLE PRECISION (A-H,M,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	IMPLICIT INTEGER (I)

 	Pi=4.D0*DATan(1.D0)

      If (sigma.GT.(1.d11)) then
		sm11=-1
		sm12=0
		sm21=0
		sm22=-1
	else
		if (epaisseurmetal.EQ.0) epaisseurmetal=1.d-16
		mu=4.d-7*Pi
		epsvide=1.d-9/(36*Pi)

		miniG=dsqrt(Pi*f*1.D9*mu*sigma)
		miniZ=dsqrt(Pi*f*1.D9*mu/sigma)
		Zeta=DCMPLX(miniZ,miniZ)
		Zgamma=DCMPLX(miniG,miniG)
		Zgamd=Zgamma*epaisseurmetal	

		Zgamdsinh=Zsinhyperb(Zgamd)
		Zgamdcosh=Zcoshyperb(Zgamd)		
	  	Zgamdcoth=Zgamdcosh/Zgamdsinh	

		Zco=Zeta*Zgamdcoth		  	
		Zsi=Zeta/Zgamdsinh
C		write(*,*)'uuu',Zsi,Zco
		Zp=Zsi
		Za=Zco-Zsi
		Zb=Za
C	write(*,*)'uuu',Zp,Za

		Zdenom=(Za+Zp+DZoI)*(Zb+Zp+DZoII)-Zp*Zp
		Zsm11=((Za+Zp-DZoI)*(Zb+Zp+DZoII)-Zp*Zp)/Zdenom
		Zsm12=(2*Zp*dsqrt(dZoI*dZoII))/Zdenom
		Zsm21=(2*Zp*dsqrt(dZoI*dZoII))/Zdenom
		Zsm22=((Za+Zp+DZoI)*(Zb+Zp-DZoII)-Zp*Zp)/Zdenom

C		dZp=1/(sigma*epaisseurmetal)
C		denom=dZoI*dZoII+dZp*dZoI+dZp*dZoII
C		sm11=(-dZoI*dZoII-dZp*dZoI+dZp*dZoII)/denom
C		sm12=(2*dZp*dsqrt(dZoI*dZoII))/denom
C		sm21=(2*dZp*dsqrt(dZoI*dZoII))/denom
C		sm22=(-dZoI*dZoII+dZp*dZoI-dZp*dZoII)/denom

		sm11=Dreal(Zsm11)
		sm12=Dreal(Zsm12)
		sm21=Dreal(Zsm21)
		sm22=Dreal(Zsm22)
		
C		write(*,*)' ',sm11,sm12,Zp

	Endif


C     *****************************************************************************  

 26   Format(1(f12.6,1x))  
 
      END
	   
C	 *******************************
C	 �    NOUVEAU SOUS-PROGRAMME   �
C	 � 	COHEN Ludovic (Fevrier2001)�
C	 �		CosHyperbolique 	   �
C      �	   d'un nombre complexe	   �
C	 *******************************

      function Zcoshyperb(z)

      implicit double precision(a-h,o-y)
	implicit double complex (z)

      r=Dreal(z)
	ri=Dimag(z)

	preel=Dcosh(r)*Dcos(ri)
	pimagin=Dsin(ri)*Dsinh(r)

	Zcoshyperb=DCMPLX(preel,pimagin)

      return
      end

C	 *******************************
C	 �    NOUVEAU SOUS-PROGRAMME   �
C	 � 	COHEN Ludovic (Fevrier2001)�
C	 �		SinHyperbolique 	   �
C      �	   d'un nombre complexe	   �
C	 *******************************

      function Zsinhyperb(z)

      implicit double precision(a-h,o-y)
	implicit double complex (z)

      r=Dreal(z)
	ri=Dimag(z)

	preel=Dsinh(r)*Dcos(ri)
	pimagin=Dsin(ri)*Dcosh(r)

	Zsinhyperb=DCMPLX(preel,pimagin)

      return
      end

