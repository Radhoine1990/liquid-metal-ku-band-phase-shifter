	SUBROUTINE MaChaine(Cprop2,v3,ZDC11,ZDC12,ZDC21,ZDC22)

C       ******************************************************************** 
C       �                                                                  �
C       �        TRAITEMENT DE LA LAME DIELECTRIQUE D EPAISEUR H,Er        �
C       �         *-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*         � 
C       �                                                                  � 
C       �         PROGRAMMATION DE LA MATRICE MODIFIEE DE CHAINE           �
C       �            EN TERME D ONDE INCIDENTE ET REFLECHIE                � 
C       �                  -----------------------------                   � 
C       �                                                                  � 
C       ********************************************************************

      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
	IMPLICIT DOUBLE COMPLEX (Z)

	IF (Cprop2.GE.0.D0) THEN
		Propg=DSQRT(Cprop2)
		Au=Propg*v3
		Aux=DCosh(Au) 
		Aux1=DSinh(Au)
		ZDC11=DCMPLX(Aux,0.d0)
		ZDC12=DCMPLX(Aux1,0.d0)
		ZDC21=DCMPLX(Aux1,0.d0)
  		ZDC22=ZDC11
	Else
	 	Propg=DSQRT(-Cprop2)
	    Au=Propg*v3
          Aux=DCos(Au)
		Aux1=DSin(Au)
		ZDC11=DCMPLX(Aux,0.d0)
		ZDC12=DCMPLX(0.d0,Aux1)
		ZDC21=DCMPLX(0.d0,Aux1)
          ZDC22=ZDC11
	Endif
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE MatScatt(m,n,Freq,a,v2,v3,b,n01,n02,DZo2,DZo3,
     &					Dmil2,Dmil3,
     &					ZchainE11,ZchainE12,ZchainE21,ZchainE22,
     &					ZchainH11,ZchainH12,ZchainH21,ZchainH22)

C       ******************************************************************** 
C       �                                                                  �
C       �        TRAITEMENT DE LA LAME DIELECTRIQUE D EPAISEUR H,Er        �
C       �         *-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*         � 
C       �                                                                  � 
C       �           PROGRAMMATION DE LA MATRICE DE LA CHAINE MODIFIEE      �
C       �               EN TERME D ONDE INCIDENTE ET REFLECHIE             � 
C       �                      -----------------------------               � 
C       �                                                                  �
C       �                         �  ZA"2=(C2)*ZA2  �                      �
C       �                         �  ZB"2=(C2)*ZB2  �                      �
C       �                                                                  � 
C       ******************************************************************** 

      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)

	DIMENSION ZchainE11(n01,n02),ZchainE12(n01,n02)
	DIMENSION ZchainE21(n01,n02),ZchainE22(n01,n02)
	DIMENSION ZchainH11(n01,n02),ZchainH12(n01,n02)
	DIMENSION ZchainH21(n01,n02),ZchainH22(n01,n02)

	Zero=DCMPLX(0.d0,0.d0)

C		---------------------------------------------------------------
C	    |	                                                          |
C	    |	  TRANSFORMATION DES ONDES INCIDENTES EN MODES TE et TM   |   
C	    |	                                                          |   
C		---------------------------------------------------------------
               
	Cprop2=Cky(Freq,m,n,Dmil2,a,b)
      Cprp2=Cky(Freq,m,n,Dmil3,a,b)
                                           
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*

      EouH='E'
               
      ZYnge=ZYnIII(EouH,Dmil2,Freq,Cprop2) 
      ZYnde=ZYnIII(EouH,Dmil3,Freq,Cprp2) 
       
C		-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
       
      EouH='H'
        
      ZYngh=ZYnIII(EouH,Dmil2,Freq,Cprop2) 
      ZYndh=ZYnIII(EouH,Dmil3,Freq,Cprp2) 

C		|                                                             |
C		|COEFFICIENT DE LA MATRICE DE CHAINE H2 POUR LES MODES TE & TM|   
C		|                                                             |        

	CALL MaChaine(Cprop2,v2,ZA2,ZB2,ZC2,ZD2)
							
	ZZB2te=ZB2/ZYnge
	ZZB2th=ZB2/ZYngh

	ZC2te=ZC2*ZYnge
	ZC2th=ZC2*ZYngh

C		|                                                             |
C		|COEFFICIENT DE LA MATRICE DE CHAINE H3 POUR LES MODES TE & TM|   
C		|                                                             | 
                                     
	CALL MaChaine(Cprp2,v3,ZA3,ZB3,ZC3,ZD3)

	ZZB3te=ZB3/ZYnde
	ZZB3th=ZB3/ZYndh

	ZC3te=ZC3*ZYnde
	ZC3th=ZC3*ZYndh

C                 -------------------------------------------------
C				|                                               |
C				|   COEFFICIENT DE LA MATRICE DE CHAINE H2,H3   |   
C				|                                               |   
C                 -------------------------------------------------

	ZchtE11=ZA2*ZA3+ZZB3te*ZC2te		
	ZchtE12=ZA3*ZZB2te+ZZB3te*ZD2
	ZchtE21=ZC3te*ZA2+ZD3*ZC2te						
	ZchtE22=ZC3te*ZZB2te+ZD3*ZD2

	ZchtH11=ZA2*ZA3+ZZB3th*ZC2th		
	ZchtH12=ZA3*ZZB2th+ZZB3th*ZD2
	ZchtH21=ZC3th*ZA2+ZD3*ZC2th						
	ZchtH22=ZC3th*ZZB2th+ZD3*ZD2

C                 -------------------------------------------------
C				|                                               |
C				|   COEFFICIENT DE LA MATRICE DE "S" DEDUITE DE |   
C				|        DE LA MATRICE DE CHAINE RESULTANTE     |   
C				|                                               |   
C                 --------------------------------------------------

	ZDNOME=ZchtE11*DZo3+ZchtE12+ZchtE21*DZo2*DZo3+ZchtE22*DZo2
		
	If(ZDNOME.EQ.ZEro)ZDNOME=1.d-16
			
	ZchainE11(m,n)=(ZchtE11*DZo3+ZchtE12-ZchtE21*DZo2*DZo3
     &                                      -ZchtE22*DZo2)/ZDNOME
	ZchainE12(m,n)=2.d0*(ZchtE11*ZchtE22-ZchtE12*ZchtE21)
     &                                   *DSQRT(DZo2*DZo3)/ZDNOME
	ZchainE21(m,n)=2.d0*DSQRT(DZo2*DZo3)/ZDNOME
	ZchainE22(m,n)=(-ZchtE11*DZo3+ZchtE12-ZchtE21*DZo2*DZo3
     &                                      +ZchtE22*DZo2)/ZDNOME

	ZDNOMH=ZchtH11*DZo3+ZchtH12+ZchtH21*DZo2*DZo3+ZchtH22*DZo2
		
	If(ZDNOMH.EQ.Zero)ZDNOMH=1.d-16
		
	ZchainH11(m,n)=(ZchtH11*DZo3+ZchtH12-ZchtH21*DZo2*DZo3
     &                                      -ZchtH22*DZo2)/ZDNOMH
	ZchainH12(m,n)=2.d0*(ZchtH11*ZchtH22-ZchtH12*ZchtH21)
     &                                   *DSQRT(DZo2*DZo3)/ZDNOMH
	ZchainH21(m,n)=2.d0*DSQRT(DZo2*DZo3)/ZDNOMH
	ZchainH22(m,n)=(-ZchtH11*DZo3+ZchtH12-ZchtH21*DZo2*DZo3
     &                                      +ZchtH22*DZo2)/ZDNOMH

      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE MatScattEM(Freq,a,v2,v3,b,DZo2,DZo3,Dmil2,Dmil3,
     &                                    ZchaintEM11,ZchaintEM12,
     &                                    ZchaintEM21,ZchaintEM22)

C       ******************************************************************** 
C       �                                                                  �
C       �        TRAITEMENT DE LA LAME DIELECTRIQUE D EPAISEUR H,Er        �
C       �         *-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*-*-*-*-*-*-*-*-*         � 
C       �                                                                  � 
C       �           PROGRAMMATION DE LA MATRICE DE LA CHAINE MODIFIEE      �
C       �               EN TERME D ONDE INCIDENTE ET REFLECHIE             � 
C       �                      -----------------------------               � 
C       �                                                                  �
C       �                         �  ZA"2=(C2)*ZA2  �                      �
C       �                         �  ZB"2=(C2)*ZB2  �                      �
C       �                                                                  � 
C       ******************************************************************** 

      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)

	Zero=DCMPLX(0.d0,0.d0)

C		---------------------------------------------------------------
C	    |	                                                          |
C	    |	  TRANSFORMATION DES ONDES INCIDENTES EN MODES TE et TM   |   
C	    |	                                                          |   
C		---------------------------------------------------------------
               
	Cprop2=Cky(Freq,1,1,Dmil2,a,b)
      Cprp2=Cky(Freq,1,1,Dmil3,a,b)
                                        
C	 *-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
       
      EouH='H'
        
      ZYngh=ZYnIII(EouH,Dmil2,Freq,Cprop2) 
      ZYndh=ZYnIII(EouH,Dmil3,Freq,Cprp2) 

C				|                                                             |
C				|COEFFICIENT DE LA MATRICE DE CHAINE H2 POUR LES MODES TE & TM|   
C				|                                                             | 
       
	CALL MaChaine(Cprop2,v2,ZA2,ZB2,ZC2,ZD2)
							
	ZZB2th=ZB2/ZYngh
	ZC2th=ZC2*ZYngh

C				|                                                             |
C				|COEFFICIENT DE LA MATRICE DE CHAINE H3 POUR LES MODES TE & TM|   
C				|                                                             | 
                                     
	CALL MaChaine(Cprp2,v3,ZA3,ZB3,ZC3,ZD3)

	ZZB3th=ZB3/ZYndh
	ZC3th=ZC3*ZYndh

C                 -------------------------------------------------
C				|                                               |
C				|   COEFFICIENT DE LA MATRICE DE CHAINE H2,H3   |   
C				|                                               |   
C                 -------------------------------------------------

	ZchtH11=ZA2*ZA3+ZZB3th*ZC2th		
	ZchtH12=ZA3*ZZB2th+ZZB3th*ZD2
	ZchtH21=ZC3th*ZA2+ZD3*ZC2th						
	ZchtH22=ZC3th*ZZB2th+ZD3*ZD2

C                 -------------------------------------------------
C				|                                               |
C				|   COEFFICIENT DE LA MATRICE DE "S" DEDUITE DE |   
C				|        DE LA MATRICE DE CHAINE RESULTANTE     |   
C				|                                               |   
C                 --------------------------------------------------

	ZDNOMH=ZchtH11*DZo3+ZchtH12+ZchtH21*DZo2*DZo3+ZchtH22*DZo2
		
	If(ZDNOMH.EQ.Zero)ZDNOMH=1.d-16
		
	ZchaintEM11=(ZchtH11*DZo3+ZchtH12-ZchtH21*DZo2*DZo3
     &                                      -ZchtH22*DZo2)/ZDNOMH
	ZchaintEM12=2.d0*(ZchtH11*ZchtH22-ZchtH12*ZchtH21)
     &                                   *DSQRT(DZo2*DZo3)/ZDNOMH
	ZchaintEM21=2.d0*DSQRT(DZo2*DZo3)/ZDNOMH
	ZchaintEM22=(-ZchtH11*DZo3+ZchtH12-ZchtH21*DZo2*DZo3
     &                                      +ZchtH22*DZo2)/ZDNOMH
				 
C                 -----------------------------------------------------
C				|                                                   |
C				|   CALCUL DES ONDES B2 ET B3 A PARTIR DE A2 ET A3  |
C				|                                                   |   
C                 -----------------------------------------------------

      END
