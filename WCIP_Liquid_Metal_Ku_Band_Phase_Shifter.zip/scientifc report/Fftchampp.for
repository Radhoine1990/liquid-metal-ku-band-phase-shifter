C		liste des programmes:FFTchmcc,FFTchmc,FFTchpl
C							 FFTSZY1,FFTSZY2,FFTZYS11,FFTZYS22
C					function:tetha(x,y)

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE FFTchmccc(Nsource,DZoI,DZoII,n01,n02,Ipolar,ISpost,
     &				   DH1s,DH2s,ZEtot,ZJtot,ZZJtot,
     &				   ZEtotz,ZJtotz,ZZJtotz,ZBIx,ZBIIx,ZBIz,ZBIIz,
     &				   ZAImox,ZAIImox,ZAInoz,ZAIInoz,ZAImx,ZAIImx,
     &				   ZAInz,ZAIInz,ZBImx,ZBIImx,ZBInz,ZBIInz,
     &				   ZEIx,ZEIIx,ZEIz,ZEIIz,ZJIx,ZJIIx,ZJIz,ZJIIz)
    
C       ************************************************************************
C       �                                                                      �
C       �  *-*-*           DETERMINATION DES CHAMPS TRANSVERSES         *-*-*  �
C       �                                                                      �
C	  �			                                                             �
C	  �			         |       CHAMP ELECTRIQUE:	   [Et]        |         �
C	  �			         |       CHAMP MAGNETIQUE:     [Jt]        |         �
C       �                                                                      � 
C       ************************************************************************ 
     
      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER(DZero=0.d0)
      DIMENSION ZBIx(n01,n02),ZBImx(n01,n02)
      DIMENSION ZBInz(n01,n02),ZBIInz(n01,n02)
      DIMENSION ZBIIx(n01,n02),ZBIz(n01,n02),ZBIIz(n01,n02)
      DIMENSION ZAImx(n01,n02),ZAIImx(n01,n02),ZAInz(n01,n02)
      DIMENSION ZAIInz(n01,n02),ZBIImx(n01,n02)
      DIMENSION ZEIx(n01,n02),ZEIz(n01,n02),ZEIIx(n01,n02)
      DIMENSION ZJIx(n01,n02),ZJIz(n01,n02),ZJIIx(n01,n02)
      DIMENSION ZEIIz(n01,n02),ZJIIz(n01,n02)
      DIMENSION ZAImox(n01,n02),ZAIImox(n01,n02)
      DIMENSION ZAInoz(n01,n02),ZAIInoz(n01,n02)    
      DIMENSION DH2s(n01,n02),DH1s(n01,n02)

C      ==========================================================
                                            
      Do 15 m=1,n01 
		Do 15 n=1,n02   
C      *--*--* Suivant Ox *--*--*
                                  
			ZAImx(m,n)=ZBIx(m,n)+ZAImox(m,n)/DSQRT(DZoI)
			ZAIImx(m,n)=ZBIIx(m,n)+ZAIImox(m,n)/DSQRT(DZoII)

C      *--*--* Suivant Oz *--*--*
                                                               
			ZAInz(m,n)=ZBIz(m,n)+ZAInoz(m,n)/DSQRT(DZoI)
			ZAIInz(m,n)=ZBIIz(m,n)+ZAIInoz(m,n)/DSQRT(DZoII)
                                                
C       &&----&&----&&----&&----&&----&&----&&----&&----&&----&&----&&

			ZEIx(m,n)=(ZAImx(m,n)+ZBImx(m,n))*DSQRT(DZoI)    
			ZEIIx(m,n)=(ZAIImx(m,n)+ZBIImx(m,n))*DSQRT(DZoII)             
			ZEIz(m,n)=(ZAInz(m,n)+ZBInz(m,n))*DSQRT(DZoI)
			ZEIIz(m,n)=(ZAIInz(m,n)+ZBIInz(m,n))*DSQRT(DZoII)

              ZJIx(m,n)=(ZAImx(m,n)-ZBImx(m,n))/DSQRT(DZoI)
              ZJIIx(m,n)=(ZAIImx(m,n)-ZBIImx(m,n))/DSQRT(DZoII)                
              ZJIz(m,n)=(ZAInz(m,n)-ZBInz(m,n))/DSQRT(DZoI)
              ZJIIz(m,n)=(ZAIInz(m,n)-ZBIInz(m,n))/DSQRT(DZoII)
                  
C        **************************************************************** 
C        �                                                              �
C        � &&--&& DETERMINATION DE L'ADMITTANCE VUE PAR LA SOURCE &&--&&� 
C        �                  Yin=Somme[ZJ/ZEo]                           �
C        �                                                              �
C	   ****************************************************************

              ZJIx(m,n)=ZJIx(m,n)+ZJIIx(m,n)
              ZJIz(m,n)=ZJIz(m,n)+ZJIIz(m,n)                 

			If(Nsource.EQ.1)Then			              
				If((ISpost.EQ.1).OR.(ISpost.EQ.3))Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
c						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIx(m,n)*0.1d0     	
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZJIz(m,n)               
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
						ZZJtotz=ZZJtotz+DH2s(m,n)*ZJIz(m,n)     
					Endif
					Endif	
					Endif													
				Endif														
     				If(ISpost.EQ.2)Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     	
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZJIz(m,n)               
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
						ZZJtotz=ZZJtotz+DH2s(m,n)*ZJIz(m,n)     
					Endif
					Endif	
					Endif													
				Endif														 
 			Else
C		--------------- 	If(Nsource.EQ.2) Then ---------------			              

				If((ISpost.EQ.1).OR.(ISpost.EQ.3))Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIx(m,n)     	
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIz(m,n)              
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIx(m,n)     

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
						ZZJtotz=ZZJtotz+DH2s(m,n)*ZEIz(m,n)     
					Endif
					Endif
					Endif
				Else	
     				If(ISpost.EQ.2)Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIx(m,n)     	
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIz(m,n)               
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIx(m,n)     

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
						ZZJtotz=ZZJtotz+DH2s(m,n)*ZEIIz(m,n)     
					Endif
					Endif	
					Endif													
				Endif													
				Endif
  			Endif
 15	Continue
C Dans FFTchmc, avant la fin de la subroutine :
      write(*,*) '=== DEBUG FFTchmc ==='
      write(*,*) 'ZEtot=', ZEtot
      write(*,*) 'ZJtot=', ZJtot  
      write(*,*) 'ZZJtot=', ZZJtot
      write(*,*) '=== FIN DEBUG ==='
	End




	SUBROUTINE FFTchmc(Nsource,DZoI,DZoII,n01,n02,Ipolar,ISpost,
     &				   DH1s,DH2s,ZEtot,ZJtot,ZZJtot,
     &				   ZEtotz,ZJtotz,ZZJtotz,ZBIx,ZBIIx,ZBIz,ZBIIz,
     &				   ZAImox,ZAIImox,ZAInoz,ZAIInoz,ZAImx,ZAIImx,
     &				   ZAInz,ZAIInz,ZBImx,ZBIImx,ZBInz,ZBIInz,
     &				   ZEIx,ZEIIx,ZEIz,ZEIIz,ZJIx,ZJIIx,ZJIz,ZJIIz)
    
C       ************************************************************************
C       �                                                                      �
C       �  *-*-*           DETERMINATION DES CHAMPS TRANSVERSES         *-*-*  �
C       �                                                                      �
C	  �			                                                             �
C	  �			         |       CHAMP ELECTRIQUE:	   [Et]        |         �
C	  �			         |       CHAMP MAGNETIQUE:     [Jt]        |         �
C       �                                                                      � 
C       ************************************************************************ 
     
      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER(DZero=0.d0)
      DIMENSION ZBIx(n01,n02),ZBImx(n01,n02)
      DIMENSION ZBInz(n01,n02),ZBIInz(n01,n02)
      DIMENSION ZBIIx(n01,n02),ZBIz(n01,n02),ZBIIz(n01,n02)
      DIMENSION ZAImx(n01,n02),ZAIImx(n01,n02),ZAInz(n01,n02)
      DIMENSION ZAIInz(n01,n02),ZBIImx(n01,n02)
      DIMENSION ZEIx(n01,n02),ZEIz(n01,n02),ZEIIx(n01,n02)
      DIMENSION ZJIx(n01,n02),ZJIz(n01,n02),ZJIIx(n01,n02)
      DIMENSION ZEIIz(n01,n02),ZJIIz(n01,n02)
      DIMENSION ZAImox(n01,n02),ZAIImox(n01,n02)
      DIMENSION ZAInoz(n01,n02),ZAIInoz(n01,n02)    
      DIMENSION DH2s(n01,n02),DH1s(n01,n02)

C      ==========================================================
                                            
      Do 15 m=1,n01 
		Do 15 n=1,n02   
C      *--*--* Suivant Ox *--*--*
                                  
			ZAImx(m,n)=ZBIx(m,n)+ZAImox(m,n)/DSQRT(DZoI)
			ZAIImx(m,n)=ZBIIx(m,n)+ZAIImox(m,n)/DSQRT(DZoII)

C      *--*--* Suivant Oz *--*--*
                                                               
			ZAInz(m,n)=ZBIz(m,n)+ZAInoz(m,n)/DSQRT(DZoI)
			ZAIInz(m,n)=ZBIIz(m,n)+ZAIInoz(m,n)/DSQRT(DZoII)
                                                
C       &&----&&----&&----&&----&&----&&----&&----&&----&&----&&----&&

			ZEIx(m,n)=(ZAImx(m,n)+ZBImx(m,n))*DSQRT(DZoI)    
			ZEIIx(m,n)=(ZAIImx(m,n)+ZBIImx(m,n))*DSQRT(DZoII)             
			ZEIz(m,n)=(ZAInz(m,n)+ZBInz(m,n))*DSQRT(DZoI)
			ZEIIz(m,n)=(ZAIInz(m,n)+ZBIInz(m,n))*DSQRT(DZoII)

              ZJIx(m,n)=(ZAImx(m,n)-ZBImx(m,n))/DSQRT(DZoI)
              ZJIIx(m,n)=(ZAIImx(m,n)-ZBIImx(m,n))/DSQRT(DZoII)                
              ZJIz(m,n)=(ZAInz(m,n)-ZBInz(m,n))/DSQRT(DZoI)
              ZJIIz(m,n)=(ZAIInz(m,n)-ZBIInz(m,n))/DSQRT(DZoII)
                  
C        **************************************************************** 
C        �                                                              �
C        � &&--&& DETERMINATION DE L'ADMITTANCE VUE PAR LA SOURCE &&--&&� 
C        �                  Yin=Somme[ZJ/ZEo]                           �
C        �                                                              �
C	   ****************************************************************

              ZJIx(m,n)=ZJIx(m,n)+ZJIIx(m,n)
              ZJIz(m,n)=ZJIz(m,n)+ZJIIz(m,n)                 

			If(Nsource.EQ.1)Then			              
				If((ISpost.EQ.1).OR.(ISpost.EQ.3))Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIx(m,n)*0.05d0  ! NOUVEAU 
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIz(m,n)               ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIz(m,n)*0.05d0  ! NOUVEAU 
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIx(m,n)*0.05d0  ! NOUVEAU 

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtotz=ZZJtotz+DH2s(m,n)*ZJIz(m,n)     ! ANCIEN
						ZZJtotz=ZZJtotz+DH1s(m,n)*ZJIz(m,n)*0.05d0  ! NOUVEAU 
					Endif
					Endif	
					Endif													
				Endif														
     				If(ISpost.EQ.2)Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     	! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIx(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIz(m,n)               ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIz(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZJIx(m,n)     ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZJIx(m,n)*0.05d0  ! NOUVEAU - 

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtotz=ZZJtotz+DH2s(m,n)*ZJIz(m,n)     ! ANCIEN
						ZZJtotz=ZZJtotz+DH1s(m,n)*ZJIz(m,n)*0.05d0  ! NOUVEAU 
					Endif
					Endif	
					Endif													
				Endif														 
 			Else
C		--------------- 	If(Nsource.EQ.2) Then ---------------			              

				If((ISpost.EQ.1).OR.(ISpost.EQ.3))Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIx(m,n)     	! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIx(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIz(m,n)              ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIz(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIx(m,n)     ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIx(m,n)*0.05d0  ! NOUVEAU - 

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtotz=ZZJtotz+DH2s(m,n)*ZEIz(m,n)     ! ANCIEN
						ZZJtotz=ZZJtotz+DH1s(m,n)*ZEIz(m,n)*0.05d0  ! NOUVEAU 
					Endif
					Endif
					Endif
				Else	
     				If(ISpost.EQ.2)Then
					If(IPolar.EQ.1) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIx(m,n)     	! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIIx(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.2) Then                
						ZEtot=ZEtot+DH1s(m,n)*ZEIIz(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIz(m,n)               ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIIz(m,n)*0.05d0  ! NOUVEAU - 
                      Else 
					If(IPolar.EQ.3) Then
						ZEtot=ZEtot+DH1s(m,n)*ZEIIx(m,n) 
						ZJtot=ZJtot+DH1s(m,n)*ZJIx(m,n)     
C						ZZJtot=ZZJtot+DH2s(m,n)*ZEIIx(m,n)     ! ANCIEN
						ZZJtot=ZZJtot+DH1s(m,n)*ZEIIx(m,n)*0.05d0  ! NOUVEAU - 

						ZEtotz=ZEtotz+DH1s(m,n)*ZEIIz(m,n) 
						ZJtotz=ZJtotz+DH1s(m,n)*ZJIz(m,n)     
C						ZZJtotz=ZZJtotz+DH2s(m,n)*ZEIIz(m,n)     ! ANCIEN
						ZZJtotz=ZZJtotz+DH1s(m,n)*ZEIIz(m,n)*0.05d0  ! NOUVEAU 
					Endif
					Endif	
					Endif													
				Endif													
				Endif
  			Endif
 15	Continue

C === DEBUG ===
      write(*,*) '=== DEBUG FFTchmc ==='
      write(*,*) 'ZEtot=', ZEtot
      write(*,*) 'ZJtot=', ZJtot  
      write(*,*) 'ZZJtot=', ZZJtot
      write(*,*) '=== FIN DEBUG ==='

	End
















C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      SUBROUTINE FFTSZY1(Nsource,DZc,l,ITache,IPolar,ZEtot,ZJtot,ZZJtot,
     &		  		   ZEtotz,ZJtotz,ZZJtotz,DRZ11,DIZ11,DRZ12,DIZ12,			
     &				   DS11,DS12,DPh11,DPh12,
     &				   DRZ11z,DIZ11z,DRZ12z,DIZ12z,			
     &				   DS11z,DS12z,DPh11z,DPh12z,
     &				   DRY11,DIY11,DRY12,DIY12)

C	  ************************************************************************
C	  �                                                                      �
C	  �  *-*-*    DETERMINATION DES PARAMETRES DE DIFFTRACTION      *-*-*    �
C	  �                                                                      �
C	  �         |               MATRICE IMPEDANCE:	[Z]        |             �
C	  �         |              MATRICE ADMITTANCE:	[Y]        |             �
C	  �         |          MATRICE DE DIFFRACTION:	[S]        |             �
C	  �                                                                      �
C	  ************************************************************************
       
      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	PARAMETER (Deg=57.29578d0,DZero=0.d0)   	
	Zero=DCMPLX(DZero,DZero)                       
    	Z1=DCMPLX(1.d0,0.d0) 
     
      If(ITache.EQ.1) Then             	
		If(Nsource.EQ.1)Then
			If(ZEtot.EQ.Zero) ZEtot=1.d-16
			ZYadmit11=ZJtot/ZEtot
              ZYadmit12=-ZZJtot/ZEtot

	        DRY11=DReal(ZYadmit11)
			DIY11=Dimag(ZYadmit11)  
	        DRY12=DReal(ZYadmit12)
 			DIY12=Dimag(ZYadmit12)

			ZYadmit11=DCMPLX(DRY11,DIY11)
              ZYadmit12=DCMPLX(DRY12,DIY12)
 			If(ZYadmit11.EQ.Zero) ZYadmit11=1.d-16
			If(ZYadmit12.EQ.Zero) ZYadmit12=1.d-16   
			       
			ZDeter=ZYadmit11**2-ZYadmit12**2       		
			If(ZDeter.EQ.Zero) ZDeter=1.d-16			 
			Zzimped11=ZYadmit11/ZDeter
			Zzimped12=-ZYadmit12/ZDeter	 

			Zdet=(Z1+DZc*ZYadmit11)*(Z1+DZc*ZYadmit11)
			Zdet=Zdet-(DZc)**2*ZYadmit12*ZYadmit12
		    If(Zdet.EQ.Zero) Zdet=1.d-16			  
			ZS11=(Z1-DZc*ZYadmit11)*(Z1+DZc*ZYadmit11)
			ZS11=(ZS11+DZc*DZc*ZYadmit12*ZYadmit12)/Zdet
			ZS12=-2.d0*DZc*ZYadmit12/Zdet
			ZS21=-2.d0*DZc*ZYadmit12/Zdet
			ZS22=(Z1+DZc*ZYadmit11)*(Z1-DZc*ZYadmit11)
			ZS22=(ZS22+DZc*ZYadmit12*DZc*ZYadmit12)/Zdet

			If(Ipolar.EQ.3)Then
				If(ZEtotz.EQ.Zero) ZEtotz=1.d-16
				ZYadmit11z=ZJtotz/ZEtotz
				ZYadmit12z=-ZZJtotz/ZEtotz

				DRY11z=DReal(ZYadmit11z)
				DIY11z=Dimag(ZYadmit11z)  
				DRY12z=DReal(ZYadmit12z)
 				DIY12z=Dimag(ZYadmit12z)

				ZYadmit11z=DCMPLX(DRY11z,DIY11z)
				ZYadmit12z=DCMPLX(DRY12z,DIY12z)         
				If(ZYadmit11z.EQ.Zero) ZYadmit11z=1.d-16
				If(ZYadmit12z.EQ.Zero) ZYadmit12z=1.d-16

				ZDeterz=ZYadmit11z**2-ZYadmit12z**2       		
				If(ZDeterz.EQ.Zero) ZDeterz=1.d-16			 
				Zzimped11z=ZYadmit11z/ZDeterz
				Zzimped12z=-ZYadmit12z/ZDeterz

				Zdetz=(Z1+DZc*ZYadmit11z)*(Z1+DZc*ZYadmit11z)
				Zdetz=Zdetz-(DZc)**2*ZYadmit12z*ZYadmit12z
				If(Zdetz.EQ.Zero) Zdetz=1.d-16			  
				ZS11z=(Z1-DZc*ZYadmit11z)*(Z1+DZc*ZYadmit11z)
				ZS11z=(ZS11z+DZc*DZc*ZYadmit12z*ZYadmit12z)/Zdetz
				ZS12z=-2.d0*DZc*ZYadmit12z/Zdetz
				ZS21z=-2.d0*DZc*ZYadmit12z/Zdetz
				ZS22z=(Z1+DZc*ZYadmit11z)*(Z1-DZc*ZYadmit11z)
				ZS22z=(ZS22z+DZc*ZYadmit12z*DZc*ZYadmit12z)/Zdetz
			Endif
		Else
			If(Nsource.EQ.2)Then	
C	Dans ce cas ZZJtot est en fait �gal � ZZEtot						              
				If(ZJtot.EQ.Zero) ZJtot=1.d-16
				Zzimped11=ZEtot/ZJtot
				Zzimped12=-ZZJtot/ZJtot

				DRZ11=DReal(Zzimped11)
				DIZ11=Dimag(Zzimped11)  
				DRZ12=DReal(Zzimped12)
 				DIZ12=Dimag(Zzimped12)

				Zzimped11=DCMPLX(DRZ11,DIZ11)
				Zzimped12=DCMPLX(DRZ12,DIZ12)  
				If(Zzimped11.EQ.Zero) Zzimped11=1.d-16
				If(Zzimped12.EQ.Zero) Zzimped12=1.d-16  
				        
				ZDeter=Zzimped11**2-Zzimped12**2       		
				If(ZDeter.EQ.Zero) ZDeter=1.d-16			 
				ZYadmit11=Zzimped11/ZDeter
				ZYadmit12=-Zzimped12/ZDeter	
					
				Zdet=(Zzimped11+DZc)*(Zzimped11+DZc)
	            Zdet=Zdet-Zzimped12*Zzimped12
				If(Zdet.EQ.Zero) Zdet=1.d-16			  
				ZS11=(Zzimped11-DZc)*(Zzimped11+DZc)
				ZS11=(ZS11-Zzimped12*Zzimped12)/Zdet
				ZS12=2.d0*DZc*Zzimped12/Zdet
				ZS21=2.d0*DZc*Zzimped12/Zdet
				ZS22=(Zzimped11+DZc)*(Zzimped11-DZc)
				ZS22=(ZS22-Zzimped12*Zzimped12)/Zdet
				If(Ipolar.EQ.3)Then
					If(ZJtotz.EQ.Zero) ZJtotz=1.d-16
					Zzimped11z=ZEtotz/ZJtotz
					Zzimped12z=-ZZJtotz/ZJtotz

					DRZ11z=DReal(Zzimped11z)
					DIZ11z=Dimag(Zzimped11z)  
					DRZ12z=DReal(Zzimped12z)
 					DIZ12z=Dimag(Zzimped12z)

					Zzimped11z=DCMPLX(DRZ11z,DIZ11z)
					Zzimped12z=DCMPLX(DRZ12z,DIZ12)
					If(Zzimped11z.EQ.Zero) Zzimped11z=1.d-16
					If(Zzimped12z.EQ.Zero) Zzimped12z=1.d-16

					ZDeterz=Zzimped11z**2-Zzimped12z**2       				 		
					If(ZDeterz.EQ.Zero) ZDeterz=1.d-16			 		
					ZYadmit11z=Zzimped11z/ZDeterz
					ZYadmit12z=-Zzimped12z/ZDeterz

					Zdetz=(Zzimped11z+DZc)*(Zzimped11z+DZc)
					Zdetz=Zdet-Zzimped12z*Zzimped12z
					If(Zdetz.EQ.Zero) Zdetz=1.d-16			  
					ZS11z=(Zzimped11z-DZc)*(Zzimped11z+DZc)
					ZS11z=(ZS11z-Zzimped12z*Zzimped12z)/Zdetz
					ZS12z=2.d0*DZc*Zzimped12z/Zdetz
					ZS21z=2.d0*DZc*Zzimped12z/Zdetz
					ZS22z=(Zzimped11z+DZc)*(Zzimped11z-DZc)
					ZS22z=(ZS22z-Zzimped12z*Zzimped12z)/Zdetz												
				Endif
			Endif
		Endif
		DPar1=Dreal(ZS11)
		DPaI1=DImag(ZS11)
		DPar2=Dreal(ZS12)
		DPaI2=DImag(ZS12)
		DPar3=Dreal(ZS21)
		DPaI3=DImag(ZS21)
		DPar4=Dreal(ZS22)
		DPaI4=DImag(ZS22)	
		DPh11=Deg*Tetha(DPar1,DPaI1)
		DPh12=Deg*Tetha(DPar2,DPaI2)
		DPh21=Deg*Tetha(DPar3,DPaI3)
		DPh22=Deg*Tetha(DPar4,DPaI4)

		Do While(DPh11.Lt.-180.d0)
			DPh11=DPh11+360.d0
	    End do
		Do While(DPh11.Gt.180.d0)
		    DPh11=DPh11-360.d0
	    End do
		Do While(DPh12.Lt.-180.d0)
		    DPh12=DPh12+360.d0
	    End do
		Do While(DPh12.Gt.180.d0)
		    DPh12=DPh12-360.d0
	    End do
		Do While(DPh21.Lt.-180.d0)
		    DPh21=DPh21+360.d0
	    End do
		Do While(DPh21.Gt.180.d0)
		    DPh21=DPh21-360.d0			  
	    End do
		Do While(DPh22.Lt.-180.d0)
		    DPh22=DPh22+360.d0
	    End do
		Do while(DPh22.Gt.180.d0)
		    DPh22=DPh22-360.d0
	    End do

		DS11=20*DLOG10(CDABS(ZS11))
		DS12=20*DLOG10(CDABS(ZS12))
		DS21=20*DLOG10(CDABS(ZS21))
		DS22=20*DLOG10(CDABS(ZS22))
	    DRZ11=DReal(Zzimped11)
		DIZ11=Dimag(Zzimped11)  
	    DRZ12=DReal(Zzimped12)
 		DIZ12=Dimag(Zzimped12)
		DRZ21=DReal(Zzimped21)
		DIZ21=Dimag(Zzimped21)
 	    DRZ22=DReal(Zzimped22)
		DIZ22=Dimag(Zzimped22)  

		If(DS11.GT.DZero)DS11=DZero
		If(DS12.GT.DZero)DS12=DZero
		If(DS21.GT.DZero)DS21=DZero
		If(DS22.GT.DZero)DS22=DZero

		If(Ipolar.EQ.3)Then
			DPar1z=Dreal(ZS11z)
			DPaI1=DImag(ZS11z)
			DPar2z=Dreal(ZS12z)
			DPaI2z=DImag(ZS12z)
			DPar3z=Dreal(ZS21z)
			DPaI3z=DImag(ZS21z)
			DPar4z=Dreal(ZS22z)
			DPaI4z=DImag(ZS22z)
	
			DPh11z=Deg*Tetha(DPar1z,DPaI1z)
			DPh12z=Deg*Tetha(DPar2z,DPaI2z)
			DPh21z=Deg*Tetha(DPar3z,DPaI3z)
			DPh22z=Deg*Tetha(DPar4z,DPaI4z)
	
			Do While(DPh11z.Lt.-180.d0)
				DPh11z=DPh11z+360.d0
	        End do
			Do While(DPh11z.Gt.180.d0)
			  	DPh11z=DPh11z-360.d0
	        End do
			Do While(DPh12z.Lt.-180.d0)
			    DPh12z=DPh12z+360.d0
	        End do
			Do While(DPh12z.Gt.180.d0)
			    DPh12z=DPh12z-360.d0
	        End do
			Do While(DPh21z.Lt.-180.d0)
			    DPh21z=DPh21z+360.d0
	        End do
			Do While(DPh21z.Gt.180.d0)
			    DPh21z=DPh21z-360.d0			  
	        End do
			Do While(DPh22z.Lt.-180.d0)
			    DPh22z=DPh22z+360.d0
	        End do
			Do while(DPh22z.Gt.180.d0)
			    DPh22z=DPh22z-360.d0
	        End do

			DS11z=20*DLOG10(CDABS(ZS11z))
			DS12z=20*DLOG10(CDABS(ZS12z))
			DS21z=20*DLOG10(CDABS(ZS21z))
			DS22z=20*DLOG10(CDABS(ZS22z))
	        DRZ11z=DReal(Zzimped11z)
			DIZ11z=Dimag(Zzimped11z)  
	        DRZ12z=DReal(Zzimped12z)
 			DIZ12z=Dimag(Zzimped12z)
			DRZ21z=DReal(Zzimped21z)
			DIZ21z=Dimag(Zzimped21z)
 	        DRZ22z=DReal(Zzimped22z)
			DIZ22z=Dimag(Zzimped22z)  

			If(DS11z.GT.DZero)DS11z=DZero
			If(DS12z.GT.DZero)DS12z=DZero
			If(DS21z.GT.DZero)DS21z=DZero
			If(DS22z.GT.DZero)DS22z=DZero
		Endif
		
C	 =================== CALCUL DE LA MATRICE DE COUPLAGE ================

      write(*,*)
      write(*,*)'Iteration=',l
      write(*,*)

	write(*,*)'Impedance 11 =>>',DRZ11,DIZ11
      write(*,*)'Impedance 12 =>>',DRZ12,DIZ12
	  
	write(*,*)'DS11=',DS11, '  ', 'DS12=',DS12
	write(*,*)'DS21=',DS21, '  ', 'DS22=',DS22
	write(*,*)
    	write(*,*)'================= Phase ============================='
      write(*,*)DPh11,Dph12
      write(*,*)DPh21,Dph22
    	write(*,*)'====================================================='
	write(*,*)

		If(IPolar.EQ.3)Then

 		write(*,*)'voie gauche'
		write(*,*)'Impedance  =>>',DRZ11z,DIZ11z
		write(*,*)'Impedance  =>>',DRZ12z,DIZ12z
	  	write(*,*)
		write(*,*)'DS11=',DS11z, '  ', 'DS12=',DS12z
		write(*,*)'DS21=',DS21z, '  ', 'DS22=',DS22z
		write(*,*)
    		write(*,*)'================= Phase =========================='
		write(*,*)DPh11z,Dph12z
		write(*,*)DPh21z,Dph22z
    		write(*,*)'=================================================='
		write(*,*)

		Endif
	Endif
	End

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************
  
      SUBROUTINE FFTSZY2(Nsource,DZc,ITache,IPolar,ZEtot,ZJtot,ZZJtot,
     &	ZEtotz,ZJtotz,ZZJtotz,DRZ11,DIZ11,DRZ12,DIZ12,DS11,DS12,			
     &DPh11,DPh12,DRZ11z,DIZ11z,DRZ12z,DIZ12z,DS11z,DS12z,DPh11z,			
     &DPh12z,DRY11,DIY11,DRY12,DIY12,a,b,DPixelx,DPixely,nn01,nn02)
 
C       **********************************************************************
C	  �                                                                    �
C	  �  *-*-*    DETERMINATION DES PARAMETRES DE DIFFTRACTION      *-*-*  �
C	  �                                                                    �
C	  �         |               MATRICE IMPEDANCE:	[Z]        |           �
C	  �         |              MATRICE ADMITTANCE:	[Y]        |           �
C	  �         |          MATRICE DE DIFFRACTION:	[S]        |           �
C	  �                                                                    �
C	  **********************************************************************      

      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
	PARAMETER (Deg=57.29578d0,DZero=0.d0)   	
	Zero=DCMPLX(DZero,DZero)                       
    	Z1=DCMPLX(1.d0,0.d0) 
     
      If(ITache.NE.1) Then             	
		If(Nsource.EQ.1)Then
			If(ZEtot.EQ.Zero) ZEtot=1.d-16
			ZYadmit11=(ZJtot*DPixely*nn02)/(ZEtot*DPixelx*nn01)
              ZYadmit12=-(ZZJtot*DPixely*nn02)/(ZEtot*DPixelx*nn01)

	        DRY11=DReal(ZYadmit11)
			DIY11=Dimag(ZYadmit11) 
	        DRY12=DReal(ZYadmit12)
 			DIY12=Dimag(ZYadmit12)

			ZYadmit11=DCMPLX(DRY11,DIY11)
              ZYadmit12=DCMPLX(DRY12,DIY12)
 			If(ZYadmit11.EQ.Zero) ZYadmit11=1.d-16
			If(ZYadmit12.EQ.Zero) ZYadmit12=1.d-16
			          
			ZDeter=ZYadmit11**2-ZYadmit12**2       		
		    If(ZDeter.EQ.Zero) ZDeter=1.d-16			 
			Zzimped11=ZYadmit11/ZDeter
			Zzimped12=-ZYadmit12/ZDeter	
			 
			Zdet=(Z1+DZc*ZYadmit11)*(Z1+DZc*ZYadmit11)
			Zdet=Zdet-(DZc)**2*ZYadmit12*ZYadmit12
		    If(Zdet.EQ.Zero) Zdet=1.d-16			  
			ZS11=(Z1-DZc*ZYadmit11)*(Z1+DZc*ZYadmit11)
			ZS11=(ZS11+DZc*DZc*ZYadmit12*ZYadmit12)/Zdet
			ZS12=-2.d0*DZc*ZYadmit12/Zdet
			ZS21=-2.d0*DZc*ZYadmit12/Zdet
			ZS22=(Z1+DZc*ZYadmit11)*(Z1-DZc*ZYadmit11)
			ZS22=(ZS22+DZc*ZYadmit12*DZc*ZYadmit12)/Zdet

			If(Ipolar.EQ.3)Then
				If(ZEtotz.EQ.Zero) ZEtotz=1.d-16
				ZYadmit11z=ZJtotz/ZEtotz
				ZYadmit12z=-ZZJtotz/ZEtotz
					
				DRY11z=DReal(ZYadmit11z)
				DIY11z=Dimag(ZYadmit11z)  
				DRY12z=DReal(ZYadmit12z)
 				DIY12z=Dimag(ZYadmit12z)

				ZYadmit11z=DCMPLX(DRY11z,DIY11z)
				ZYadmit12z=DCMPLX(DRY12z,DIY12z)         
				If(ZYadmit11z.EQ.Zero) ZYadmit11z=1.d-16
				If(ZYadmit12z.EQ.Zero) ZYadmit12z=1.d-16

				ZDeterz=ZYadmit11z**2-ZYadmit12z**2       		
				If(ZDeterz.EQ.Zero) ZDeterz=1.d-16			 
				Zzimped11z=ZYadmit11z/ZDeterz
				Zzimped12z=-ZYadmit12z/ZDeterz

				Zdetz=(Z1+DZc*ZYadmit11z)*(Z1+DZc*ZYadmit11z)
				Zdetz=Zdetz-(DZc)**2*ZYadmit12z*ZYadmit12z
				If(Zdetz.EQ.Zero) Zdetz=1.d-16			  
				ZS11z=(Z1-DZc*ZYadmit11z)*(Z1+DZc*ZYadmit11z)
				ZS11z=(ZS11z+DZc*DZc*ZYadmit12z*ZYadmit12z)/Zdetz
				ZS12z=-2.d0*DZc*ZYadmit12z/Zdetz
				ZS21z=-2.d0*DZc*ZYadmit12z/Zdetz
				ZS22z=(Z1+DZc*ZYadmit11z)*(Z1-DZc*ZYadmit11z)
				ZS22z=(ZS22z+DZc*ZYadmit12z*DZc*ZYadmit12z)/Zdetz
			Endif
		Else
		If(Nsource.EQ.2)Then
C	Dans ce cas ZZJtot est en fait �gal � ZZEtot					              
			If(ZJtot.EQ.Zero) ZJtot=1.d-16
			Zzimped11=ZEtot/ZJtot
              Zzimped12=-ZZJtot/ZJtot
	        DRZ11=DReal(Zzimped11)
			DIZ11=Dimag(Zzimped11)  
	        DRZ12=DReal(Zzimped12)
 			DIZ12=Dimag(Zzimped12)

			Zzimped11=DCMPLX(DRZ11,DIZ11)
              Zzimped12=DCMPLX(DRZ12,DIZ12)  
			If(Zzimped11.EQ.Zero) Zzimped11=1.d-16
			If(Zzimped12.EQ.Zero) Zzimped12=1.d-16 
			         
			ZDeter=Zzimped11**2-Zzimped12**2       		
		    If(ZDeter.EQ.Zero) ZDeter=1.d-16			 
			ZYadmit11=Zzimped11/ZDeter
			ZYadmit12=-Zzimped12/ZDeter	
				
			Zdet=(Zzimped11+DZc)*(Zzimped11+DZc)
			Zdet=Zdet-Zzimped12*Zzimped12
		    If(Zdet.EQ.Zero) Zdet=1.d-16			  
			ZS11=(Zzimped11-DZc)*(Zzimped11+DZc)
			ZS11=(ZS11-Zzimped12*Zzimped12)/Zdet
			ZS12=2.d0*DZc*Zzimped12/Zdet
			ZS21=2.d0*DZc*Zzimped12/Zdet
			ZS22=(Zzimped11+DZc)*(Zzimped11-DZc)
			ZS22=(ZS22-Zzimped12*Zzimped12)/Zdet
			If(Ipolar.EQ.3)Then
				If(ZJtotz.EQ.Zero) ZJtotz=1.d-16
				Zzimped11z=ZEtotz/ZJtotz
				Zzimped12z=-ZZJtotz/ZJtotz

				DRZ11z=DReal(Zzimped11z)
				DIZ11z=Dimag(Zzimped11z)  
				DRZ12z=DReal(Zzimped12z)
 				DIZ12z=Dimag(Zzimped12z)

				Zzimped11z=DCMPLX(DRZ11z,DIZ11z)
				Zzimped12z=DCMPLX(DRZ12z,DIZ12)
				If(Zzimped11z.EQ.Zero) Zzimped11z=1.d-16
				If(Zzimped12z.EQ.Zero) Zzimped12z=1.d-16

				ZDeterz=Zzimped11z**2-Zzimped12z**2       			 		
				If(ZDeterz.EQ.Zero) ZDeterz=1.d-16			 			 
				ZYadmit11z=Zzimped11z/ZDeterz
				ZYadmit12z=-Zzimped12z/ZDeterz

				Zdetz=(Zzimped11z+DZc)*(Zzimped11z+DZc)
				Zdetz=Zdet-Zzimped12z*Zzimped12z
				If(Zdetz.EQ.Zero) Zdetz=1.d-16			  
				ZS11z=(Zzimped11z-DZc)*(Zzimped11z+DZc)
				ZS11z=(ZS11z-Zzimped12z*Zzimped12z)/Zdetz
				ZS12z=2.d0*DZc*Zzimped12z/Zdetz
				ZS21z=2.d0*DZc*Zzimped12z/Zdetz
				ZS22z=(Zzimped11z+DZc)*(Zzimped11z-DZc)
				ZS22z=(ZS22z-Zzimped12z*Zzimped12z)/Zdetz												
			Endif
		Endif
		Endif

		DPar1=Dreal(ZS11)
		DPaI1=DImag(ZS11)
		DPar2=Dreal(ZS12)
		DPaI2=DImag(ZS12)
		DPar3=Dreal(ZS21)
		DPaI3=DImag(ZS21)
		DPar4=Dreal(ZS22)
		DPaI4=DImag(ZS22)
	
		DPh11=Deg*Tetha(DPar1,DPaI1)
		DPh12=Deg*Tetha(DPar2,DPaI2)
		DPh21=Deg*Tetha(DPar3,DPaI3)
		DPh22=Deg*Tetha(DPar4,DPaI4)

		Do While(DPh11.Lt.-180.d0)
			DPh11=DPh11+360.d0
	    End do
		Do While(DPh11.Gt.180.d0)
			DPh11=DPh11-360.d0
	    End do
		Do While(DPh12.Lt.-180.d0)
			DPh12=DPh12+360.d0
	    End do
		Do While(DPh12.Gt.180.d0)
			DPh12=DPh12-360.d0
	    End do
		Do While(DPh21.Lt.-180.d0)
			DPh21=DPh21+360.d0
	    End do
		Do While(DPh21.Gt.180.d0)
			DPh21=DPh21-360.d0			  
	    End do
		Do While(DPh22.Lt.-180.d0)
			DPh22=DPh22+360.d0
	    End do
		Do while(DPh22.Gt.180.d0)
			DPh22=DPh22-360.d0
	    End do

		DS11=20*DLOG10(CDABS(ZS11))
		DS12=20*DLOG10(CDABS(ZS12))
		DS21=20*DLOG10(CDABS(ZS21))
		DS22=20*DLOG10(CDABS(ZS22))
	    DRZ11=DReal(Zzimped11)
		DIZ11=Dimag(Zzimped11)  
	    DRZ12=DReal(Zzimped12)
 		DIZ12=Dimag(Zzimped12)
		DRZ21=DReal(Zzimped21)
		DIZ21=Dimag(Zzimped21)
 	    DRZ22=DReal(Zzimped22)
		DIZ22=Dimag(Zzimped22)  

		If(DS11.GT.DZero)DS11=DZero
		If(DS12.GT.DZero)DS12=DZero
		If(DS21.GT.DZero)DS21=DZero
		If(DS22.GT.DZero)DS22=DZero

		If(Ipolar.EQ.3)Then
			DPar1z=Dreal(ZS11z)
			DPaI1=DImag(ZS11z)
			DPar2z=Dreal(ZS12z)
			DPaI2z=DImag(ZS12z)
			DPar3z=Dreal(ZS21z)
			DPaI3z=DImag(ZS21z)
			DPar4z=Dreal(ZS22z)
			DPaI4z=DImag(ZS22z)
	
			DPh11z=Deg*Tetha(DPar1z,DPaI1z)
			DPh12z=Deg*Tetha(DPar2z,DPaI2z)
			DPh21z=Deg*Tetha(DPar3z,DPaI3z)
			DPh22z=Deg*Tetha(DPar4z,DPaI4z)
	
			Do While(DPh11z.Lt.-180.d0)
				DPh11z=DPh11z+360.d0
	        End do
			Do While(DPh11z.Gt.180.d0)
			  	DPh11z=DPh11z-360.d0
	        End do
			Do While(DPh12z.Lt.-180.d0)
			    DPh12z=DPh12z+360.d0
	        End do
			Do While(DPh12z.Gt.180.d0)
			    DPh12z=DPh12z-360.d0
	        End do
			Do While(DPh21z.Lt.-180.d0)
			    DPh21z=DPh21z+360.d0
	        End do
			Do While(DPh21z.Gt.180.d0)
			    DPh21z=DPh21z-360.d0			  
	        End do
			Do While(DPh22z.Lt.-180.d0)
			    DPh22z=DPh22z+360.d0
	        End do
			Do while(DPh22z.Gt.180.d0)
			    DPh22z=DPh22z-360.d0
	        End do

			DS11z=20*DLOG10(CDABS(ZS11z))
			DS12z=20*DLOG10(CDABS(ZS12z))
			DS21z=20*DLOG10(CDABS(ZS21z))
			DS22z=20*DLOG10(CDABS(ZS22z))
	        DRZ11z=DReal(Zzimped11z)
			DIZ11z=Dimag(Zzimped11z)  
	        DRZ12z=DReal(Zzimped12z)
 			DIZ12z=Dimag(Zzimped12z)
			DRZ21z=DReal(Zzimped21z)
			DIZ21z=Dimag(Zzimped21z)
 	        DRZ22z=DReal(Zzimped22z)
			DIZ22z=Dimag(Zzimped22z)  
			If(DS11z.GT.DZero)DS11z=DZero
			If(DS12z.GT.DZero)DS12z=DZero
			If(DS21z.GT.DZero)DS21z=DZero
			If(DS22z.GT.DZero)DS22z=DZero
		Endif
c	
C	=================== CALCUL DE LA MATRICE DE COUPLAGE ================

	write(*,*)'Impedance  =>>',DRZ11,DIZ11
      write(*,*)'Impedance  =>>',DRZ12,DIZ12
	write(*,*)'DS11=',DS11, '  ', 'DS12=',DS12
	write(*,*)'DS21=',DS21, '  ', 'DS22=',DS22
	write(*,*)
    	write(*,*)'================= Phase ============================='
      write(*,*)DPh11,Dph12
      write(*,*)DPh21,Dph22
    	write(*,*)'====================================================='
	write(*,*)

	If(IPolar.EQ.3)Then

	write(*,*)'voie gauche'
	write(*,*)'Impedance  =>>',DRZ11z,DIZ11z
      write(*,*)'Impedance  =>>',DRZ12z,DIZ12z
	  
	write(*,*)'DS11=',DS11z, '  ', 'DS12=',DS12z
	write(*,*)'DS21=',DS21z, '  ', 'DS22=',DS22z
	write(*,*)
    	write(*,*)'================= Phase ============================='
      write(*,*)DPh11z,Dph12z
      write(*,*)DPh21z,Dph22z
    	write(*,*)'====================================================='
	write(*,*)

	Endif
	Endif
	End



*******************************************************
* VUONG T�n Phu   LEN7 - ENSEEIHT                     *
* Decembre 1997                                       *
*******************************************************

      function tetha(x,y)

      implicit double precision(a-h,o-z)
      pi=4.d0*datan(1.d0)

      if(x.eq.0.d0.and.y.ge.0.d0) goto 2
      if(x.eq.0.d0.and.y.lt.0.d0) goto 3
      if(x.gt.0.d0.and.y.gt.0.d0) goto 4
      if(x.lt.0.d0.and.y.ge.0.d0) goto 5
      if(x.lt.0.d0.and.y.lt.0.d0) goto 6
      if(x.gt.0.d0.and.y.lt.0.d0) goto 7

  2   tetha=pi/2.d0
      goto 8
  3   tetha=-pi/2.d0
      goto 8
  4   tetha=datan(y/x)
      goto 8
  5   tetha=pi-datan(-y/x)
      goto 8
  6   tetha=pi+datan(y/x)
      goto 8
  7   tetha=-datan(-y/x)
  8   continue
      return
      end
