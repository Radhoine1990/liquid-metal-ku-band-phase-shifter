# Microsoft Developer Studio Generated NMAKE File, Based on patch.dsp
!IF "$(CFG)" == ""
CFG=patch - Win32 Debug
!MESSAGE No configuration specified. Defaulting to patch - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "patch - Win32 Release" && "$(CFG)" != "patch - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "patch.mak" CFG="patch - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "patch - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "patch - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

F90=df.exe
RSC=rc.exe

!IF  "$(CFG)" == "patch - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\patch.exe"

!ELSE 

ALL : "$(OUTDIR)\patch.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\Fftadmit.obj"
	-@erase "$(INTDIR)\fftcal.obj"
	-@erase "$(INTDIR)\Fftchain.obj"
	-@erase "$(INTDIR)\Fftchampp.obj"
	-@erase "$(INTDIR)\Fftdif4256.obj"
	-@erase "$(INTDIR)\FftMenu.obj"
	-@erase "$(INTDIR)\FftRayy256.obj"
	-@erase "$(INTDIR)\Fftref255.obj"
	-@erase "$(INTDIR)\Fftsoub.obj"
	-@erase "$(INTDIR)\patch.obj"
	-@erase "$(INTDIR)\Pertes.obj"
	-@erase "$(INTDIR)\Rdon.obj"
	-@erase "$(INTDIR)\Zcaract.obj"
	-@erase "$(INTDIR)\ZFftcosirec.obj"
	-@erase "$(INTDIR)\ZFftmodal2566.obj"
	-@erase "$(INTDIR)\ZFftmodtEM.obj"
	-@erase "$(OUTDIR)\patch.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
F90_PROJ=/include:"$(INTDIR)\\" /compile_only /nologo /warn:nofileopt\
 /module:"Release/" /object:"Release/" 
F90_OBJS=.\Release/
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\patch.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib /nologo /subsystem:console /incremental:no\
 /pdb:"$(OUTDIR)\patch.pdb" /machine:I386 /out:"$(OUTDIR)\patch.exe" 
LINK32_OBJS= \
	"$(INTDIR)\Fftadmit.obj" \
	"$(INTDIR)\fftcal.obj" \
	"$(INTDIR)\Fftchain.obj" \
	"$(INTDIR)\Fftchampp.obj" \
	"$(INTDIR)\Fftdif4256.obj" \
	"$(INTDIR)\FftMenu.obj" \
	"$(INTDIR)\FftRayy256.obj" \
	"$(INTDIR)\Fftref255.obj" \
	"$(INTDIR)\Fftsoub.obj" \
	"$(INTDIR)\patch.obj" \
	"$(INTDIR)\Pertes.obj" \
	"$(INTDIR)\Rdon.obj" \
	"$(INTDIR)\Zcaract.obj" \
	"$(INTDIR)\ZFftcosirec.obj" \
	"$(INTDIR)\ZFftmodal2566.obj" \
	"$(INTDIR)\ZFftmodtEM.obj"

"$(OUTDIR)\patch.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "patch - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\patch.exe" "$(OUTDIR)\DF50.PDB"

!ELSE 

ALL : "$(OUTDIR)\patch.exe" "$(OUTDIR)\DF50.PDB"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\DF50.PDB"
	-@erase "$(INTDIR)\Fftadmit.obj"
	-@erase "$(INTDIR)\fftcal.obj"
	-@erase "$(INTDIR)\Fftchain.obj"
	-@erase "$(INTDIR)\Fftchampp.obj"
	-@erase "$(INTDIR)\Fftdif4256.obj"
	-@erase "$(INTDIR)\FftMenu.obj"
	-@erase "$(INTDIR)\FftRayy256.obj"
	-@erase "$(INTDIR)\Fftref255.obj"
	-@erase "$(INTDIR)\Fftsoub.obj"
	-@erase "$(INTDIR)\patch.obj"
	-@erase "$(INTDIR)\Pertes.obj"
	-@erase "$(INTDIR)\Rdon.obj"
	-@erase "$(INTDIR)\Zcaract.obj"
	-@erase "$(INTDIR)\ZFftcosirec.obj"
	-@erase "$(INTDIR)\ZFftmodal2566.obj"
	-@erase "$(INTDIR)\ZFftmodtEM.obj"
	-@erase "$(OUTDIR)\patch.exe"
	-@erase "$(OUTDIR)\patch.ilk"
	-@erase "$(OUTDIR)\patch.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
F90_PROJ=/include:"$(INTDIR)\\" /compile_only /nologo /debug:full\
 /warn:nofileopt /module:"Debug/" /object:"Debug/" /pdbfile:"Debug/DF50.PDB" 
F90_OBJS=.\Debug/
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\patch.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib /nologo /stack:0x5f5e100 /subsystem:console\
 /incremental:yes /pdb:"$(OUTDIR)\patch.pdb" /debug /machine:I386\
 /out:"$(OUTDIR)\patch.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\Fftadmit.obj" \
	"$(INTDIR)\fftcal.obj" \
	"$(INTDIR)\Fftchain.obj" \
	"$(INTDIR)\Fftchampp.obj" \
	"$(INTDIR)\Fftdif4256.obj" \
	"$(INTDIR)\FftMenu.obj" \
	"$(INTDIR)\FftRayy256.obj" \
	"$(INTDIR)\Fftref255.obj" \
	"$(INTDIR)\Fftsoub.obj" \
	"$(INTDIR)\patch.obj" \
	"$(INTDIR)\Pertes.obj" \
	"$(INTDIR)\Rdon.obj" \
	"$(INTDIR)\Zcaract.obj" \
	"$(INTDIR)\ZFftcosirec.obj" \
	"$(INTDIR)\ZFftmodal2566.obj" \
	"$(INTDIR)\ZFftmodtEM.obj"

"$(OUTDIR)\patch.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.for{$(F90_OBJS)}.obj:
   $(F90) $(F90_PROJ) $<  

.f{$(F90_OBJS)}.obj:
   $(F90) $(F90_PROJ) $<  

.f90{$(F90_OBJS)}.obj:
   $(F90) $(F90_PROJ) $<  

.fpp{$(F90_OBJS)}.obj:
   $(F90) $(F90_PROJ) $<  


!IF "$(CFG)" == "patch - Win32 Release" || "$(CFG)" == "patch - Win32 Debug"
SOURCE=.\Fftadmit.for

"$(INTDIR)\Fftadmit.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\fftcal.for

"$(INTDIR)\fftcal.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Fftchain.for

"$(INTDIR)\Fftchain.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Fftchampp.for

"$(INTDIR)\Fftchampp.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Fftdif4256.for

"$(INTDIR)\Fftdif4256.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\FftMenu.for

"$(INTDIR)\FftMenu.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\FftRayy256.for

"$(INTDIR)\FftRayy256.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Fftref255.for

"$(INTDIR)\Fftref255.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Fftsoub.for

"$(INTDIR)\Fftsoub.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\patch.for

"$(INTDIR)\patch.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Pertes.for

"$(INTDIR)\Pertes.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Rdon.for

"$(INTDIR)\Rdon.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\Zcaract.for

"$(INTDIR)\Zcaract.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\ZFftcosirec.for

"$(INTDIR)\ZFftcosirec.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\ZFftmodal2566.for

"$(INTDIR)\ZFftmodal2566.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\ZFftmodtEM.for

"$(INTDIR)\ZFftmodtEM.obj" : $(SOURCE) "$(INTDIR)"



!ENDIF 

