      SUBROUTINE SCATERRING_MATR1(n01,n02,IPolar,ISpost,Dn2,Dn3,
     &                           Ipol1,Ipol2,Dnn1,Dnn2,Dnn3,Dnom,DHp,
     &                           DHi,DHm,DHs,via,ZBBImx,ZBBIImx,
     &                           ZBBInz,ZBBIInz,ZAImox,ZAIImox,
     &                           ZAInoz,ZAIInoz,ZBIx,ZBIIx,ZBIz,ZBIIz,
     &                           sm11,sm12,sm21,sm22,f,pcentx,pcenty,
     &                           DZoI,DZoII,a,b,
     &                           Zg_matrix)  ! NOUVEAU PARAMETRE

C ************************************************************************
C *                                                                      *
C **- REMPLISSAGE DE LA MATRICE DE DIFFRACTION DE LA STRUCTURE PLANAIRE-*
C *                                                                      *
C *  - Zgraphene: Imp�dance de surface du graph�ne                       *
C *                                                                      *
C *     Date: Juillet 1997 (Modifi� pour graph�ne)                       *
C *                                                                      *
C ************************************************************************
      
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER(DZero=0.D0)
      DIMENSION DHi(n01,n02),DHm(n01,n02),via(n01,n02)
      DIMENSION DHs(n01,n02),SY12(n01,n02),SY21(n01,n02)
      DIMENSION SY11(n01,n02),SY22(n01,n02),ZAIInoz(n01,n02)
      DIMENSION ZBIx(n01,n02),ZBIIx(n01,n02),ZBIz(n01,n02)
      DIMENSION ZBIIz(n01,n02),ZBImx(n01,n02),ZBIImx(n01,n02)
      DIMENSION ZBInz(n01,n02),ZBIInz(n01,n02),SY121(n01,n02)
      DIMENSION ZAInoz(n01,n02),ZAImox(n01,n02),SY222(n01,n02)
      DIMENSION SY111(n01,n02),ZAIImox(n01,n02),SY112(n01,n02)
      DIMENSION ZBBImx(n01,n02),ZBBIImx(n01,n02),DHp(n01,n02)
      DIMENSION ZBBInz(n01,n02),ZBBIInz(n01,n02)
      DIMENSION Zg_matrix(n01,n02)  ! AJOUT GRAPHENE

      DOUBLE PRECISION Zg_real, alpha_te, alpha_tm
      COMPLEX*16 Y_graphene

      Zero=DCMPLX(DZero,DZero)
      Pi=4.D0*DATan(1.D0)

C		INITIALISATION DES MATRICES

	Dk11=(-1.d0+Ipol1*Dnn1-Ipol2*Dnn2)/Dnom
	Dk22=(-1.d0-Ipol1*Dnn1+Ipol2*Dnn2)/Dnom
	Dk12=2.d0*Dnn3/Dnom
	Dk21=Dk12
		     
      Do 2 m=1,n01
      Do 2 n=1,n02           
          
          ! CALCUL DES TERMES DE MATRICE DE BASE
          SY11(m,n) = sm11*DHm(m,n) - Dn2*DHi(m,n) - DHs(m,n)	
          SY12(m,n) = sm12*DHm(m,n) + Dn3*DHi(m,n)
          SY21(m,n) = sm21*DHm(m,n) + Dn3*DHi(m,n)
          SY22(m,n) = sm22*DHm(m,n) + Dn2*DHi(m,n) - DHs(m,n)

          ! TERMES AVEC SOURCE
          SY111(m,n) = sm11*DHm(m,n) - Dn2*DHi(m,n) + Dk11*DHs(m,n)
          SY112(m,n) = sm12*DHm(m,n) + Dn3*DHi(m,n) + Dk12*DHs(m,n)
          SY121(m,n) = sm21*DHm(m,n) + Dn3*DHi(m,n) + Dk21*DHs(m,n)
          SY222(m,n) = sm22*DHm(m,n) + Dn2*DHi(m,n) + Dk22*DHs(m,n)

          ! ====================================================
          ! AJOUT DU GRAPHENE
          ! ====================================================
          
          ! PRENDRE LA PARTIE REELLE POUR LA COMPARAISON
          Zg_real = DREAL(Zg_matrix(m,n))
          
          ! SI GRAPHENE PRESENT
          If(Zg_real .LT. 1.0d8) Then
              
              ! CALCUL DE L'ADMITTANCE
              Y_graphene = 1.0d0 / Zg_matrix(m,n)
              
              ! FACTEURS DE COUPLAGE
				alpha_te = 0.00001d0  
				alpha_tm = 0.000005d0
              
              ! AJOUTER L'EFFET DU GRAPHENE
              SY11(m,n) = SY11(m,n) + alpha_te * DZoI * Y_graphene
              SY22(m,n) = SY22(m,n) + alpha_tm * DZoII * Y_graphene
              SY111(m,n) = SY111(m,n) + alpha_te * DZoI * Y_graphene
              SY222(m,n) = SY222(m,n) + alpha_tm * DZoII * Y_graphene
              
          Endif
          
          ! SUITE DU CODE EXISTANT
          ZBImx(m,n)=ZBBImx(m,n)*(1.d0-via(m,n))
          ZBIImx(m,n)=ZBBIImx(m,n)*(1.d0-via(m,n))
          ZBInz(m,n)=ZBBInz(m,n)*(1.d0-via(m,n))
          ZBIInz(m,n)=ZBBIInz(m,n)*(1.d0-via(m,n))
                            
          If(IPolar.EQ.1) Then                               
              If(ISpost.EQ.1) Then            
                  ZBIx(m,n)=SY111(m,n)*ZBImx(m,n)
     &                     +SY112(m,n)*ZBIImx(m,n) 
                  ZAImox(m,n)=DHs(m,n)*ZAImox(m,n)       
                  ZBIIx(m,n)=SY21(m,n)*ZBImx(m,n)
     &                      +SY22(m,n)*ZBIImx(m,n) 
                  ZAIImox(m,n)=ZAIImox(m,n)*DHs(m,n)
              ElseIf(ISpost.EQ.2) Then                     
                  ZBIx(m,n)=SY11(m,n)*ZBImx(m,n)
     &                     +SY12(m,n)*ZBIImx(m,n) 
                  ZAImox(m,n)=ZAImox(m,n)*DHs(m,n)               
                  ZBIIx(m,n)=SY121(m,n)*ZBImx(m,n)
     &                      +SY222(m,n)*ZBIImx(m,n) 
                  ZAIImox(m,n)=ZAIImox(m,n)*DHs(m,n)
              ElseIf(ISpost.EQ.3) Then                                                                                    
                  ZBIx(m,n)=SY111(m,n)*ZBImx(m,n)
     &                     +SY112(m,n)*ZBIImx(m,n) 
                  ZAImox(m,n)=ZAImox(m,n)*DHs(m,n)                 
                  ZBIIx(m,n)=SY121(m,n)*ZBImx(m,n)
     &                      +SY222(m,n)*ZBIImx(m,n) 
                  ZAIImox(m,n)=ZAIImox(m,n)*DHs(m,n)
              Endif
                 
              ZBIz(m,n)=SY11(m,n)*ZBInz(m,n)
     &                 +SY12(m,n)*ZBIInz(m,n) 
              ZAInoz(m,n)=ZAInoz(m,n)*DHs(m,n)                     
              ZBIIz(m,n)=SY21(m,n)*ZBInz(m,n)
     &                  +SY22(m,n)*ZBIInz(m,n) 
              ZAIInoz(m,n)=ZAIInoz(m,n)*DHs(m,n)                                 
          Else                
              If(ISpost.EQ.1) Then            
                  ZBIz(m,n)=SY111(m,n)*ZBInz(m,n)
     &                     +SY112(m,n)*ZBIInz(m,n) 
                  ZAInoz(m,n)=ZAInoz(m,n)*DHs(m,n)       
                  ZBIIz(m,n)=SY21(m,n)*ZBInz(m,n)
     &                      +SY22(m,n)*ZBIInz(m,n) 
                  ZAIInoz(m,n)=ZAIInoz(m,n)*DHs(m,n)
              ElseIf(ISpost.EQ.2) Then                       
                  ZBIz(m,n)=SY11(m,n)*ZBInz(m,n)
     &                     +SY12(m,n)*ZBIInz(m,n) 
                  ZAInoz(m,n)=ZAInoz(m,n)*DHs(m,n)               
                  ZBIIz(m,n)=SY121(m,n)*ZBInz(m,n)
     &                      +SY222(m,n)*ZBIInz(m,n) 
                  ZAIInoz(m,n)=ZAIInoz(m,n)*DHs(m,n)
              ElseIf(ISpost.EQ.3) Then                                                        
                  ZBIz(m,n)=SY111(m,n)*ZBInz(m,n)
     &                     +SY112(m,n)*ZBIInz(m,n) 
                  ZAInoz(m,n)=ZAInoz(m,n)*DHs(m,n)                  
                  ZBIIz(m,n)=SY121(m,n)*ZBInz(m,n)
     &                      +SY222(m,n)*ZBIInz(m,n) 
                  ZAIInoz(m,n)=ZAIInoz(m,n)*DHs(m,n)
              Endif
           
              ZBIx(m,n)=SY11(m,n)*ZBImx(m,n)
     &                 +SY12(m,n)*ZBIImx(m,n) 
              ZAImox(m,n)=ZAImox(m,n)*DHs(m,n)                      
              ZBIIx(m,n)=SY21(m,n)*ZBImx(m,n)
     &                  +SY22(m,n)*ZBIImx(m,n) 
              ZAIImox(m,n)=ZAIImox(m,n)*DHs(m,n)           
          Endif 

 2    Continue 
 
      END