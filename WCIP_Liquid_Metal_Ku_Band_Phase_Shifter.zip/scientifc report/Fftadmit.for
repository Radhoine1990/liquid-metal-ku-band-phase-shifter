C		liste des programmes:FABNOM2,FABNOM,FinduMot,FinduMot2,AscCode
C				   functions:Cky(Freq,m,n,Dmilieu,a,v3)
C							 YnI(EouH,Freq,v1,Cprop2) 
C							 YnII(EouH,Dmilieu,Freq,v2,Cprp2)
C							 ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprp2,Cprp3)
C							 ZYnIII(EouH,Dmilieu,Freq,Cprp2) 

C **********************************************************************
C *																	 *
C *    CALCUL DES ADMITTANCES DE MODE D'UN GUIDE COURT-CIRCUITE A UNE  *
C *    DISTANCE bi (i=1,2,3,...) EN DOUBLE PRECISION                   *  
C *																	 *
C *		(P(mn)(Er))^2=(m pi/a)^2+(n pi/b)^2-k0^2Er			         *                                                         �
C **********************************************************************
      
      FUNCTION Cky(Freq,m,n,Dmilieu,a,v3)
      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Z) 
      PARAMETER(Dzero=0.D0,Cel=3.D8)
      Pi=2.D0*DASin(1.D0)
  
      mm=m-1
      nn=n-1
      Aux1=Pi*Dble(mm)/a
      Aux2=Pi*Dble(nn)/v3
      Aux=Aux1*Aux1+Aux2*Aux2
      Ax=2*Pi*Freq*1.d9/Cel
	Ax=Ax*DSQRT(Dmilieu)
      Ax=Ax*Ax
      Cky=Aux-Ax

	End

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************
C	 YnI theorique = j*YnI du prog 
C	 YnI theorique est toujours imaginaire pur
C	 Calcul des admittances de court-circuit lorsqu'il y a un capot 
C	                                         dans l'air ou le vide

      FUNCTION YnI(EouH,Freq,v1,Cprop2)       
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Z),CHARACTER (E)
      PARAMETER (DZero=0.d0,Cel=3.D8)       

      Pi=2.D0*DASin(1.D0)
      Dmue=4*Pi*1.d-7
      DEps=1.d-9/(36*Pi)
      Omega=2*Pi*Freq*1.d9
      u1=Omega*Dmue
      u2=Omega*DEps
      
      IF (Cprop2.GE.0.D0) THEN      
		Propg=DSQRT(Cprop2)
          Aux=Propg*v1
		If(Propg.EQ.DZero)Propg=1.d-16                           
          Aux=DCoth(Aux)
          If (EouH.EQ.'H') Then                               
			YnI=u2*Aux/Propg
C                  *-*-* Modes TM *-*-*                               
          Else                               
              YnI=-Propg*Aux/u1 
C                  *-*-* Modes TE *-*-*                                                              
          EndIf                          
	ELSE
          Propg=DSQRT(-Cprop2)
          Aux=Propg*v1
		If(Propg.EQ.DZero)Propg=1.d-16                           
          Aux=DCotan(Aux)
          If (EouH.EQ.'H') Then
			YnI=-u2*Aux/Propg
C                   *-*-* Modes TM *-*-*                               
          Else
              YnI=-Propg*Aux/u1 
C                   *-*-* Modes TE *-*-*                                                                     
          EndIf
      ENDIF
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************
C	 YnII theorique = j*YnII du prog 
C	 YnII theorique est toujours imaginaire pur
C	 Calcul des admittances de court-circuit lorsqu'il y a un capot 
C	                                         dans un milieu quelconque
      
      FUNCTION YnII(EouH,Dmilieu,Freq,v2,Cprp2)       
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Z),CHARACTER (E)
      PARAMETER (DZero=0.d0,Cel=3.D8)
      Pi=2.D0*DASin(1.D0)

      Dmue=4*Pi*1.d-7
      DEps=1.d-9/(36*Pi)
      Omega=2*Pi*Freq*1.d9
      u1=Omega*Dmue
      u2=Omega*DEps*Dmilieu
      
      IF (Cprp2.GE.0.D0) THEN
		Propg=DSQRT(Cprp2)
		If(Propg.EQ.DZero)Propg=1.d-16                           
          Aux=Propg*v2
          Aux=DCoth(Aux)
          If (EouH.EQ.'H') Then
			YnII=u2*Aux/Propg
C                 *-*-* Modes TM *-*-*                           
          Else
              YnII=-Propg*Aux/u1 
C                 *-*-* Modes TE *-*-*                               
          EndIf
      ELSE
          Propg=DSQRT(-Cprp2)
		If(Propg.EQ.DZero)Propg=1.d-16                           
          Aux=Propg*v2
          Aux=DCotan(Aux)
          If (EouH.EQ.'H') Then
			YnII=-u2*Aux/Propg
C                 *-*-* Modes TM *-*-*                               
          Else
			YnII=-Propg*Aux/u1 
C                 *-*-* Modes TE *-*-*                               
          EndIf 
      EndIf                                
      END     

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      FUNCTION ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprp2,Cprp3)
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y),CHARACTER (E)
	IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER (DZero=0.d0,Cel=3.D8)
      
	Pi=2.D0*DASin(1.D0)
      Dmue=4*Pi*1.d-7
      DEps=1.d-9/(36*Pi)
      Omega=2*Pi*Freq*1.d9
      u1=Omega*Dmue
      u2=Omega*DEps*Dmil2
	u3=Omega*DEps*Dmil3

      IF ((Cprp2.GE.0.D0).AND.(Cprp3.GE.0.D0)) THEN
		Cprop3=DSQRT(Cprp3)
		Aux=Cprop3*v3
		Aux=DCoth(Aux)
          Cprop2=DSQRT(Cprp2)
          Ax=Cprop2*v2
          Ax=DTanh(Ax)
		If(Cprop2.EQ.DZero)Cprop2=1.d-16                           
		If(Cprop3.EQ.DZero)Cprop3=1.d-16                                                
		If (EouH.EQ.'H') Then
			Bx=u3*Aux/Cprop3
              Cx=Bx+u2*Ax/Cprop2
              Bx=u2/Cprop2+Bx*Ax
		    If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,u2*Cx/Cprop2/Bx)
          Else								   
			Bx=Cprop3*Aux
              Cx=Bx+Cprop2*Ax
              Bx=Cprop2+Bx*Ax
		    If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,-CProp2*Cx/u1/Bx)
          EndIf
      ENDIF
      IF ((Cprp2.LT.0.D0).AND.(Cprp3.GE.0.D0)) THEN
		Cprop3=DSQRT(Cprp3)
          Aux=Cprop3*v3
          Aux=DCoth(Aux)
          Cprop2=DSQRT(-Cprp2)
          Ax=Cprop2*v2
          Ax=DTan(Ax)
		If(Cprop2.EQ.DZero)Cprop2=1.d-16                           
		If(Cprop3.EQ.DZero)Cprop3=1.d-16                           
          If (EouH.EQ.'H') Then                                      
			Bx=u3*Aux/Cprop3
			Cx=Bx+u2*Ax/Cprop2
			Bx=-u2/Cprop2+Bx*Ax
		    If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,-u2*Cx/Bx/Cprop2)						
		Else										   
			Bx=Cprop3*Aux
              Cx=Bx-Cprop2*Ax
              Bx=Cprop2+Bx*Ax
              If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,-CProp2*Cx/Bx/u1)
          EndIf
      ENDIF
      IF ((Cprp2.GE.0.D0).AND.(Cprp3.LT.0.D0)) THEN
		Cprop3=DSQRT(-Cprp3)
          Aux=Cprop3*v3
          Aux=DCotan(Aux)
          Cprop2=DSQRT(Cprp2)
          Ax=Cprop2*v2
          Ax=DTanh(Ax)
		If(Cprop2.EQ.DZero)Cprop2=1.d-16                           
		If(Cprop3.EQ.DZero)Cprop3=1.d-16                           
          If (EouH.EQ.'H') Then                                      
			Bx=u3*Aux/Cprop3
              Cx=-Bx+u2*Ax/Cprop2
              Bx=u2/Cprop2-Bx*Ax
              If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,u2*Cx/Bx/Cprop2)			
		Else										   
			Bx=Cprop3*Aux
              Cx=Cprop2*Ax+Bx
              Bx=Cprop2+Bx*Ax
              If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,-CProp2*Cx/Bx/u1)
          EndIf
      ENDIF
      IF ((Cprp2.LT.0.D0).AND.(Cprp3.LT.0.D0)) THEN
          Cprop3=DSQRT(-Cprp3)
          Aux=Cprop3*v3
          Aux=DCotan(Aux)
          Cprop2=DSQRT(-Cprp2)
          Ax=Cprop2*v2
          Ax=DTan(Ax)
		If(Cprop2.EQ.DZero)Cprop2=1.d-16                           
		If(Cprop3.EQ.DZero)Cprop3=1.d-16                           
          If (EouH.EQ.'H') Then                                      
			Bx=u3*Aux/Cprop3
              Cx=-Bx+u2*Ax/Cprop2
              Bx=u2/Cprop2+Bx*Ax
              If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,u2*Cx/Bx/Cprop2)						
		Else										   
			Bx=Cprop3*Aux
              Cx=Bx-Cprop2*Ax
              Bx=Cprop2+Bx*Ax
              If(Bx.EQ.DZero)Bx=1.d-16                           
              ZYCnII=DCMPLX(0.d0,-CProp2*Cx/Bx/u1)
          EndIf
      ENDIF
	END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************
C	 Calcul des admittances de court-circuit lorsqu'il n'y a pas de capot
C       ZYnIII est dej� en complexe

      FUNCTION ZYnIII(EouH,Dmilieu,Freq,Cprp2)       
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y),CHARACTER (E)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER (DZero=0.d0,Cel=3.D8)
      
	Pi=2.D0*DASin(1.D0)
      Dmue=4*Pi*1.d-7
      DEps=1.d-9/(36*Pi)
      Omega=2*Pi*Freq*1.d9
      u1=Omega*Dmue
      u2=Omega*DEps*Dmilieu
      
      IF (Cprp2.GE.0.D0) THEN
		Propg=DSQRT(Cprp2)
          IF(Propg.EQ.DZero)Propg=1.d-16  
		If (EouH.EQ.'H') Then 
			ZYnIII=DCMPLX(0.d0,u2/Propg)
C                    *-*-* Modes TM *-*-*              
          Else
              ZYnIII=DCMPLX(0.d0,-Propg/u1) 
C                    *-*-* Modes TE *-*-*                                                                     
          EndIf
      ELSE
          Propg=DSQRT(-Cprp2)
          IF(Propg.EQ.DZero)Propg=1.d-16  
          If (EouH.EQ.'H') Then
			ZYnIII=DCMPLX(u2/Propg,0.d0)
C                    *-*-* Modes TM *-*-*             
          Else
              ZYnIII=DCMPLX(Propg/u1,0.d0)
C                    *-*-* Modes TE *-*-*                               
          EndIf 
      EndIf                                
      END    

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE FABNOM2(NGEN,NEXT,NU,NF,nt)
	IMPLICIT DOUBLE PRECISION (A-H,O-Z)
	CHARACTER*10 NGEN,mot,NEXT, Name,name1,MOT0,MOT2
	name=NGEN
	name1=NEXT
	ii=NF
	jj=nt
	CALL AscCode(ii,mot0)
	CALL Findumot2(mot0,l0)
	CALL AscCode(jj,mot2)
	CALL Findumot2(mot2,l2)
	l0=l0-1
	l2=l2-1
	MOT(1:1)='G'
	MOT(2:2+l0)=MOT0
	MOT(l0+2:l0+2)='M'
	MOT(l0+3:l2+l0+3)=MOT2
	CALL Findumot2(mot,lm)
	lm=lm-1
	CALL Findumot2(Name,ln)
	CALL Findumot2(name1,lna)
	name(ln+1:ln+lm+2)=mot
	name(ln+lm+3:ln+lm+5)=name1
	open(NU,file=Name,status='unknown')
C       write(*,'(t5,a)')name
	return
	end

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE FABNOM(NGEN,NEXT,NU,NF)
	IMPLICIT DOUBLE PRECISION (A-H,O-Z)
	CHARACTER*10 NGEN,mot,NEXT, Name,name1
	name=NGEN
	name1=NEXT
	ii=NF
	CALL AscCode(ii,mot)
	CALL Findumot2(mot,lm)
	lm=lm-1
	CALL Findumot2(Name,ln)
	CALL Findumot2(name1,lna)
	name(ln+1:ln+lm+1)=mot
	name(ln+lm+2:ln+lm+4)=name1
	open(NU,file=Name,status='unknown')
C       write(*,'(t5,a)')name
	return
	end

**********************************************************************
*     Procedures de gestion de fichiers                              *
*--------------------------------------------------------------------*
*     par SAUVIAC Bruno - Groupe Microondes                          *
*                        Laboratoire d'Electronique de l'ENSEEIHT    *
*     Date: Aout 1990                                                *
**********************************************************************
C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE Findumot(Nom,i,j)
	CHARACTER*7 Nom
	Do 7 ii=1,4
	if (Nom(ii:ii).eq.' ') GOTO 8
7     Continue
8     i=ii-1
	j=i+6
	End

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE Findumot2(Nom,i)
	CHARACTER*7 Nom
	Do 7 ii=1,4
	if (Nom(ii:ii).eq.' ') GOTO 8
7     Continue
8     i=ii-1
	End

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

	SUBROUTINE AscCode(i,mot)
	CHARACTER*4 mot
	nb=0
	index=i
1     if (index.GE.0) then
		index=index-10
		nb=nb+1
		GOTO 1
	endif
	index=index+10
	nb=nb-1
	if (nb.EQ.0) then
		mot(1:1)=CHAR(48+index)
		mot(2:2)='.'
		mot(3:3)=' '
	else
		mot(1:1)=CHAR(48+nb)
		mot(2:2)=CHAR(48+index)
		mot(3:3)='.'
		mot(4:4)=' '
	endif
	End 
	  