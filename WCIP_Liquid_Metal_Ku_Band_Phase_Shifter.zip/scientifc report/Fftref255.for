C		liste des programmes:FFTSOU,Reflexion,Reflexx,Reflex,ReftEM
C				   functions:DCoth(x)
C							 DCh(x)
C							 Dsh(x)
C
   
      SUBROUTINE FFTSOU(n01,n02,Ipolar,Dnom,ISpost,ZAImx,ZAIImx,
     &											 ZAInz,ZAIInz)
        
C	 ***********************************************************************
C	 *                                                                     *
C	 *  MISE EN OEUVRE DU PROCESSUS ITERATIF POUR LES CIRCUITS PLANAIRES   *
C	 *  PROGRAMME CALCULANT LES ONDES:  								   *
C	 *                                                                     *
C	 *   - INCIDENTES: ZAIm et ZAIn   :   ==> MILIEU (1)                   *
C 	 *   - INCIDENTES: ZAIIm et ZAIIn :   ==> MILIEU (2)                   *
C	 *   - REFLECHIES: ZBIm et ZBIn   :   ==> MILIEU (1)                   *
C	 *   - REFLECHIES: ZBIIm et ZBIIn :   ==> MILIEU (2)                   *
C	 *                                                                     *
C 	 *     Date: Juillet 1997                                              *
C	 ***********************************************************************
       
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)    
      PARAMETER(Dzero=0.D0)
      DIMENSION ec(n01,n02)
      DIMENSION ZAImx(n01,n02),ZAIImx(n01,n02)
      DIMENSION ZAInz(n01,n02),ZAIInz(n01,n02)
      Pi=4.D0*DATan(1.D0)

C              ************************************************** 
C              �                                                �
C              �   DEFINITION DE LA SOURCE DANS L ESPACE REEL   � 
C              �      produit de deux fonctions triangles       � 
C              �                                                �
C              **************************************************  
   
      Do 17 m=1,n01
	Do 17 n=1,n02
		ec(m,n)=1.d0             
		If(Ipolar.EQ.1) Then          
			If(ISpost.EQ.1) Then                          
				ZAImx(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIImx(m,n)=0*DCMPLX(ec(m,n),DZero)                      
              Endif                                            
			If(ISpost.EQ.2) Then                           
				ZAImx(m,n)=0*DCMPLX(ec(m,n),DZero)       
				ZAIImx(m,n)=DCMPLX(ec(m,n),DZero)                            
              Endif                                           
			If(ISpost.EQ.3) Then                                 
				ZAImx(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIImx(m,n)=DCMPLX(ec(m,n),DZero)                                                                                          
              Endif            
				ZAInz(m,n)=0*DCMPLX(ec(m,n),DZero)
				ZAIInz(m,n)=0*DCMPLX(ec(m,n),DZero)                            
		Else
		If(Ipolar.EQ.2) Then
			If(ISpost.EQ.1) Then                          
				ZAInz(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=0*DCMPLX(ec(m,n),DZero)        
              Endif                      
			If(ISpost.EQ.2) Then                           
				ZAInz(m,n)=0*DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=DCMPLX(ec(m,n),DZero)                            
              Endif             
			If(ISpost.EQ.3) Then                                 
				ZAInz(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=DCMPLX(ec(m,n),DZero)                             
              Endif            
			ZAImx(m,n)=0*DCMPLX(ec(m,n),DZero)
			ZAIImx(m,n)=0*DCMPLX(ec(m,n),DZero)                            
		Else
		If(Ipolar.EQ.3) Then
			If(ISpost.EQ.1) Then                          
				ZAImx(m,n)=DCMPLX(ec(m,n),DZero)
				ZAIImx(m,n)=0*DCMPLX(ec(m,n),DZero)
				ZAInz(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=0*DCMPLX(ec(m,n),DZero)        
              Endif                      
			If(ISpost.EQ.2) Then                    
				ZAImx(m,n)=0*DCMPLX(ec(m,n),DZero)
				ZAIImx(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAInz(m,n)=0*DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=DCMPLX(ec(m,n),DZero)                            
              Endif             
			If(ISpost.EQ.3) Then                                 
				ZAImx(m,n)=DCMPLX(ec(m,n),DZero)
				ZAIImx(m,n)=DCMPLX(ec(m,n),DZero)
				ZAInz(m,n)=DCMPLX(ec(m,n),DZero)       
				ZAIInz(m,n)=DCMPLX(ec(m,n),DZero)                             
              Endif  
 		Endif
		Endif
		Endif

		ZAImx(m,n)=ZAImx(m,n)/Dnom
		ZAIImx(m,n)=ZAIImx(m,n)/Dnom
		ZAInz(m,n)=ZAInz(m,n)/Dnom
		ZAIInz(m,n)=ZAIInz(m,n)/Dnom
 
 17   Continue 
 
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************                                   

      FUNCTION DCoth(x)
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
  
      DCoth=1.D0/DTanh(x)
 
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      FUNCTION DCh(x)
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
  
      DCh=(1.d0+DExp(-2.d0*x))/2.d0/DExp(-x)
 
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      FUNCTION Dsh(x)
      IMPLICIT DOUBLE PRECISION (A-H,O-Y)
  
      DSh=(1.d0-DExp(-2.d0*x))/2.d0/DExp(-x)
 
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      SUBROUTINE Reflexion(m,n,a,b,v1,v2,n01,n02,ICapot,DZoI,DZoII,
     &				   Freq,Dmil1,Dmil4,ZRefe1,ZRefh1,ZRefe2,ZRefh2)

C      ********************************************************************
C      �                                                                  �
C      �  MISE EN OEUVRE DE LA METHODE ITERATIVE: CALCUL DES COEFFICIENTS �
C      �      DE LA MATRICE DE REFLEXION:R�mn=(1-ZoiY�mn)/(1+ZoiY�mn)     �
C      �                     �='E': Modes TE                              �
C      �                     �='H': Modes TH                              �
C      �     Date: Juin  1997                                             �
C      �                                                                  �
C      ********************************************************************
      
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)       
      PARAMETER(Dzero=0.d0)
	DIMENSION ZRefe1(n01,n02),ZRefh1(n01,n02)
	DIMENSION ZRefe2(n01,n02),ZRefh2(n01,n02)

	Zero=DCMPLX(DZero,DZero)
     	Pi=2.D0*DASin(1.D0)

C     *-*-*-* Appel des donnees du programme et calcul de Kz *-*-*-*     
                      
      If((m.NE.1).OR.(n.NE.1)) Then
		Cprop2=Cky(Freq,m,n,Dmil1,a,b)
          Cprp2=Cky(Freq,m,n,Dmil4,a,b)
		If(ICapot.EQ.1) Then                                  

C      *-*-*-* Presence du ICapot Superieur *-*-*-*        
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*

			EouH='E'
			Ynge=YnII(EouH,Dmil1,Freq,v1,Cprop2)
			Ynde=YnII(EouH,Dmil4,Freq,v2,Cprp2)
			ZAuxe1=1.D0-DZoI*DCMPLX(DZero,Ynge)
			Zauxe2=1.D0-DZoII*DCMPLX(DZero,Ynde)
			ZAuxe11=1.D0+DZoI*DCMPLX(DZero,Ynge)
			ZAuxe22=1.D0+DZoII*DCMPLX(DZero,Ynde)
			                 
C	 *-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
        
			EouH='H'
			Yngh=YnII(EouH,Dmil1,Freq,v1,Cprop2)
			Yndh=YnII(EouH,Dmil4,Freq,v2,Cprp2)
			ZAuxh1=1.D0-DZoI*DCMPLX(DZero,Yngh)
			Zauxh2=1.D0-DZoII*DCMPLX(DZero,Yndh)
			ZAuxh11=1.D0+DZoI*DCMPLX(DZero,Yngh)
			ZAuxh22=1.D0+DZoII*DCMPLX(DZero,Yndh)                       
                                                                                                                                                                          
          else
C      *-*-*-* Sans du ICapot Superieur *-*-*-*                                           
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*

			EouH='E'               
			ZYnge=ZYnIII(EouH,Dmil1,Freq,Cprop2) 
			ZYnde=ZYnIII(EouH,Dmil4,Freq,Cprp2) 
              ZAuxe1=1.D0-DZoI*ZYnge
              Zauxe2=1.D0-DZoII*ZYnde
              ZAuxe11=1.D0+DZoI*ZYnge
              ZAuxe22=1.D0+DZoII*ZYnde
       
C	 *-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
       
			EouH='H'        
			ZYngh=ZYnIII(EouH,Dmil1,Freq,Cprop2) 
			ZYndh=ZYnIII(EouH,Dmil4,Freq,Cprp2) 
	        ZAuxh1=1.D0-DZoI*ZYngh
              Zauxh2=1.D0-DZoII*ZYndh
              ZAuxh11=1.D0+DZoI*ZYngh
              ZAuxh22=1.D0+DZoII*ZYndh      
		endif 

C	 *-*-*-* Rmn: Coefficient de Reflexion.*-*-*-*

		If(Zauxe11.EQ.Zero)Zauxe11=1.d-16                           
		If(Zauxe22.EQ.Zero)Zauxe22=1.d-16                           
		If(Zauxh11.EQ.Zero)Zauxh11=1.d-16                           
		If(Zauxh22.EQ.Zero)Zauxh22=1.d-16                         	     
  
          ZRefe1(m,n)=ZAuxe1/Zauxe11
          ZRefe2(m,n)=ZAuxe2/Zauxe22 
          ZRefh1(m,n)=ZAuxh1/Zauxh11
          ZRefh2(m,n)=ZAuxh2/Zauxh22
	Else
	    ZRefh1(m,n)=Zero
	    ZRefh2(m,n)=Zero
	Endif   
      END

C	 ***************************
C	 * Nouveau sous-programmme *
C	 ***************************

      SUBROUTINE Reflexx(m,n,a,v2,v3,b,n01,n02,DZoI,DZoII,Freq,
     &                   Dmil2,Dmil3,ZRefe1,ZRefh1,ZRefe2,ZRefh2)

C         ������������������������������������������������������������������ͻ
C         �                                                                  �
C         �  MISE EN OEUVRE DE LA METHODE ITERATIVE: CALCUL DES COEFFICIENTS �
C         �      DE LA MATRICE DE REFLEXION:R�mn=(1-ZoiY�mn)/(1+ZoiY�mn)     �
C         �                     �='E': Modes TE                              �
C         �                     �='H': Modes TH                              �
C         �     Date: Juin  1997                                             �
C         �                                                                  �
C         ������������������������������������������������������������������ͼ
      
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)       
      PARAMETER(Dzero=0.d0)
	DIMENSION ZRefe1(n01,n02),ZRefh1(n01,n02)
	DIMENSION ZRefe2(n01,n02),ZRefh2(n01,n02)
	Zero=DCMPLX(DZero,DZero)
     	Pi=2.D0*DASin(1.D0)

C     - - *-*-* Appel des donnees du programme et calcul de Kz *-*-*-* - - -     

                      
                If((m.NE.1).OR.(n.NE.1)) Then
  
                 Cprop2=Cky(Freq,m,n,Dmil2,a,b)
                 Cprop3=Cky(Freq,m,n,Dmil3,a,b)


C      *-*-*-* Presence du ICapot Superieur *-*-*-*        
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*

          EouH='E'

          ZYnge=ZYCnII(EouH,Dmil3,Dmil2,v3,v2,Freq,Cprop3,Cprop2)
          ZYnde=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)

                     ZAuxe1=1.D0-DZoI*ZYnge
                     Zauxe2=1.D0-DZoII*ZYnde

                       ZAuxe11=1.D0+DZoI*ZYnge
                       ZAuxe22=1.D0+DZoII*ZYnde
                           
*-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
        
          EouH='H'

          ZYngh=ZYCnII(EouH,Dmil3,Dmil2,v3,v2,Freq,Cprop3,Cprop2)
          ZYndh=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)


                    ZAuxh1=1.D0-DZoI*ZYngh
                    Zauxh2=1.D0-DZoII*ZYndh

                      ZAuxh11=1.D0+DZoI*ZYngh
                      ZAuxh22=1.D0+DZoII*ZYndh                       
                                                      
C &&-&&-*-*-*-* Rmn: Coefficient de Reflexion.*-*-*-*-&&-&&

		   If(Zauxe11.EQ.Zero)Zauxe11=1.d-16                           
		   If(Zauxe22.EQ.Zero)Zauxe22=1.d-16                           
		   If(Zauxh11.EQ.Zero)Zauxh11=1.d-16                           
		   If(Zauxh22.EQ.Zero)Zauxh22=1.d-16                         
		     
             ZRefe1(m,n)=ZAuxe1/Zauxe11
             ZRefe2(m,n)=ZAuxe2/Zauxe22
 
                  ZRefh1(m,n)=ZAuxh1/Zauxh11
                  ZRefh2(m,n)=ZAuxh2/Zauxh22

								Else

		                  ZRefh1(m,n)=Zero
		                  ZRefh2(m,n)=Zero
	       Endif
	   
   
       END




         SUBROUTINE Reflex(m,n,a,v1,v2,v3,b,n01,n02,ICapot,
     &			 	                     DZoI,DZoII,Freq,
     &                                   Dmil1,Dmil2,Dmil3,
     &									   ZRefe1,ZRefh1,
     &									   ZRefe2,ZRefh2)

C         ������������������������������������������������������������������ͻ
C         �                                                                  �
C         �  MISE EN OEUVRE DE LA METHODE ITERATIVE: CALCUL DES COEFFICIENTS �
C         �      DE LA MATRICE DE REFLEXION:R�mn=(1-ZoiY�mn)/(1+ZoiY�mn)     �
C         �                     �='E': Modes TE                              �
C         �                     �='H': Modes TH                              �
C         �     Date: Juin  1997                                             �
C         �                                                                  �
C         ������������������������������������������������������������������ͼ
      
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)       
      PARAMETER(Dzero=0.d0)
	DIMENSION ZRefe1(n01,n02),ZRefh1(n01,n02)
	DIMENSION ZRefe2(n01,n02),ZRefh2(n01,n02)
	Zero=DCMPLX(DZero,DZero)
     	Pi=2.D0*DASin(1.D0)

C     - - *-*-* Appel des donnees du programme et calcul de Kz *-*-*-* - - -     

                      
                If((m.NE.1).OR.(n.NE.1)) Then

                 Cprop1=Cky(Freq,m,n,Dmil1,a,b)
                 Cprop2=Cky(Freq,m,n,Dmil2,a,b)
                 Cprop3=Cky(Freq,m,n,Dmil3,a,b)

        If(ICapot.EQ.1) Then                                  

C      *-*-*-* Presence du ICapot Superieur *-*-*-*        
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*

          EouH='E'

          Ynge=YnII(EouH,Dmil1,Freq,v1,Cprop1)
          ZYnde=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)

                     ZAuxe1=1.D0-DZoI*DCMPLX(DZero,Ynge)
                     Zauxe2=1.D0-DZoII*ZYnde

                       ZAuxe11=1.D0+DZoI*DCMPLX(DZero,Ynge)
                       ZAuxe22=1.D0+DZoII*ZYnde
                           
*-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
        
          EouH='H'

          Yngh=YnII(EouH,Dmil1,Freq,v1,Cprop1)
          ZYndh=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)


                    ZAuxh1=1.D0-DZoI*DCMPLX(DZero,Yngh)
                    Zauxh2=1.D0-DZoII*ZYndh

                      ZAuxh11=1.D0+DZoI*DCMPLX(DZero,Yngh)
                      ZAuxh22=1.D0+DZoII*ZYndh                       
                                                      
                                                                                                            
C      *-*-*-* Sans du ICapot Superieur *-*-*-*        
                                             else
                                           
C      *-*-*-* rmn: Coefficient de Reflexion. Mode TE *-*-*-*


       EouH='E'
               
          ZYnge=ZYnIII(EouH,Dmil1,Freq,Cprop1) 
          ZYnde=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)

                     ZAuxe1=1.D0-DZoI*ZYnge
                     Zauxe2=1.D0-DZoII*ZYnde

                       ZAuxe11=1.D0+DZoI*ZYnge
                       ZAuxe22=1.D0+DZoII*ZYnde
       
*-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
       
       EouH='H'
        
          ZYngh=ZYnIII(EouH,Dmil1,Freq,Cprop1) 
          ZYndh=ZYCnII(EouH,Dmil2,Dmil3,v2,v3,Freq,Cprop2,Cprop3)


	              ZAuxh1=1.D0-DZoI*ZYngh
                    Zauxh2=1.D0-DZoII*ZYndh

                      ZAuxh11=1.D0+DZoI*ZYngh
                      ZAuxh22=1.D0+DZoII*ZYndh                       
      
       endif 


C &&-&&-*-*-*-* Rmn: Coefficient de Reflexion.*-*-*-*-&&-&&

		   If(Zauxe11.EQ.Zero)Zauxe11=1.d-16                           
		   If(Zauxe22.EQ.Zero)Zauxe22=1.d-16                           
		   If(Zauxh11.EQ.Zero)Zauxh11=1.d-16                           
		   If(Zauxh22.EQ.Zero)Zauxh22=1.d-16                         
		  
             ZRefe1(m,n)=ZAuxe1/Zauxe11
             ZRefe2(m,n)=ZAuxe2/Zauxe22
 
                  ZRefh1(m,n)=ZAuxh1/Zauxh11
                  ZRefh2(m,n)=ZAuxh2/Zauxh22

								Else

		                  ZRefh1(m,n)=Zero
		                  ZRefh2(m,n)=Zero
	       Endif	      
      END



      SUBROUTINE ReftEM(a,v2,b,ICapot,DZoII,Freq,Dmil2,ZRefTEM)

C         ������������������������������������������������������������������ͻ
C         �                                                                  �
C         �  MISE EN OEUVRE DE LA METHODE ITERATIVE: CALCUL DES COEFFICIENTS �
C         �      DE LA MATRICE DE REFLEXION:R�mn=(1-ZoiY�mn)/(1+ZoiY�mn)     �
C         �                     �='E': Modes TE                              �
C         �                     �='H': Modes TH                              �
C         �     Date: Juin  1997                                             �
C         �                                                                  �
C         ������������������������������������������������������������������ͼ
      
      IMPLICIT DOUBLE PRECISION (A-D,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z),CHARACTER (E)       
      PARAMETER(Dzero=0.d0)
	Zero=DCMPLX(DZero,DZero)
     	Pi=2.D0*DASin(1.D0)

C     *-*-*-* Appel des donnees du programme et calcul de Kz *-*-*-*     

      Cprop2=Cky(Freq,1,1,Dmil2,a,b)
 		      
      If(ICapot.EQ.1) Then                                  

C      *-*-*-* Presence du ICapot Superieur *-*-*-*                                   
C	 *-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
        
		EouH='H'
          Yndh=YnII(EouH,Dmil2,Freq,v2,Cprop2)                     
          Zauxh2=1.D0-DZoII*DCMPLX(DZero,Yndh)
          ZAuxh22=1.D0+DZoII*DCMPLX(DZero,Yndh)                                                                                                                                                                
      else
                                                  
C	 *-*-*-* rmn: Coefficient de Reflexion. Mode TM *-*-*-*
       
		EouH='H'        
          Yndh=YnII(EouH,Dmil2,Freq,v2,Cprop2)                     
          Zauxh2=1.D0-DZoII*DCMPLX(DZero,Yndh)
          ZAuxh22=1.D0+DZoII*DCMPLX(DZero,Yndh)                         
      endif 

C	 *-*-*-* Rmn: Coefficient de Reflexion.*-*-*-*
 
	If(Zauxh22.EQ.Zero)Zauxh22=1.d-16                           

      ZRefTEM=ZAuxh2/Zauxh22
                                      
      END
