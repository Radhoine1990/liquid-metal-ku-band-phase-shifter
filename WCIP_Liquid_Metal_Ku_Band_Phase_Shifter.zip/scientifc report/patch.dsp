# Microsoft Developer Studio Project File - Name="patch" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=patch - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "patch.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "patch.mak" CFG="patch - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "patch - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "patch - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
F90=df.exe
RSC=rc.exe

!IF  "$(CFG)" == "patch - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
CPP=cl.exe
# ADD BASE F90 /include:"Release/" /compile_only /nologo /warn:nofileopt
# ADD F90 /include:"Release/" /compile_only /nologo /warn:nofileopt
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "patch - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
CPP=cl.exe
# ADD BASE F90 /include:"Debug/" /compile_only /nologo /debug:full /warn:nofileopt
# ADD F90 /include:"Debug/" /compile_only /nologo /debug:full /warn:nofileopt
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib /nologo /stack:0x5f5e100 /subsystem:console /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "patch - Win32 Release"
# Name "patch - Win32 Debug"
# Begin Source File

SOURCE=.\DONNEE.DAT
# End Source File
# Begin Source File

SOURCE=.\Fftadmit.for
# End Source File
# Begin Source File

SOURCE=.\fftcal.for
# End Source File
# Begin Source File

SOURCE=.\Fftchain.for
# End Source File
# Begin Source File

SOURCE=.\Fftchampp.for
# End Source File
# Begin Source File

SOURCE=.\Fftdif4256.for
# End Source File
# Begin Source File

SOURCE=.\FftMenu.for
# End Source File
# Begin Source File

SOURCE=.\FftRayy256.for
# End Source File
# Begin Source File

SOURCE=.\Fftref255.for
# End Source File
# Begin Source File

SOURCE=.\Fftsoub.for
# End Source File
# Begin Source File

SOURCE=.\patch.for
# End Source File
# Begin Source File

SOURCE=.\Pertes.for
# End Source File
# Begin Source File

SOURCE=.\Rdon.for
# End Source File
# Begin Source File

SOURCE=.\Tjunction.bmp
# End Source File
# Begin Source File

SOURCE=.\Zcaract.for
# End Source File
# Begin Source File

SOURCE=.\ZFftcosirec.for
# End Source File
# Begin Source File

SOURCE=.\ZFftmodal2566.for
# End Source File
# Begin Source File

SOURCE=.\ZFftmodtEM.for
# End Source File
# End Target
# End Project
