

	SUBROUTINE MODE_INV_SCATM(n01,n02,a,b,IParois,ZA2te,
     &						ZA2th,ZA3te,ZA3th,
     &	   				    ZchainE11,ZchainE12,ZchainE21,ZchainE22,
     &	   				    ZchainH11,ZchainH12,ZchainH21,ZchainH22,
     &						ZB2mx,ZB2nz,ZB3mx,ZB3nz)

C   ����������������������������������������������������������������ͻ
C   �                                                                �
C   �      |		MISE EN OEUVRE DE LA METHODE ITERATIVE	        |  �
C   �      | CALCUL DE LA TRANSFORMEE DE FOURIER RAPIDE INVERSE   |  �
C   �      |    EN MODE TE & TM POUR LES MURS ELCT ET MAGN        |  �
C   �                                                                �
C   �    *-*- N'gongo simplice -*-*    Date: Juin  1997              �
C   �                                                                �
C   ����������������������������������������������������������������ͼ
      
      IMPLICIT DOUBLE PRECISION (A-E,F-H,O-Y)
      IMPLICIT DOUBLE COMPLEX (Z)
      PARAMETER (DZero=0.d0)
      DIMENSION T22r(n01,n02),T21r(n01,n02)
      DIMENSION ZB2mx(n01,n02),ZB3mx(n01,n02)
	DIMENSION ZB2nz(n01,n02),ZB3nz(n01,n02)
      DIMENSION ZB3te(n01,n02),ZB3th(n01,n02)
      DIMENSION ZB2te(n01,n02),ZB2th(n01,n02)
      DIMENSION ZA3te(n01,n02),ZA3th(n01,n02)
      DIMENSION ZA2te(n01,n02),ZA2th(n01,n02)

	DIMENSION ZchainE11(n01,n02),ZchainE12(n01,n02)
	DIMENSION ZchainE21(n01,n02),ZchainE22(n01,n02)
	DIMENSION ZchainH11(n01,n02),ZchainH12(n01,n02)
	DIMENSION ZchainH21(n01,n02),ZchainH22(n01,n02)

      Pi=4.D0*DATan(1.D0)
	Zero=DCMPLX(Dzero,DZero)

C      &&--&&--&&--&&--&&--&&-*-*--*-*-*-*-*-&&--&&--&&--&&--&&--&&--&&       
                      
      Do 1 m=1,n01
		Do 1 n=1,n02                      
			If((m.NE.1).OR.(n.NE.1)) Then  		 
				DNorm=DSQRT(((m-1)*Pi/a)**2+((n-1)*Pi/b)**2)                                  
                  DNorm=1.d0/DNorm                                                                    
              Else 
                  DNorm=1.d16                                                             
              Endif                                             
              If((m-1)*(n-1).EQ.0)   Then
				Sigma=1.d0
              Else
                  Sigma=2.d0
              Endif

		T21r(m,n)=(m-1)*Pi/a*DNorm*DSQRT(2*Sigma/(a*b))*a*b/n01/n02
		T22r(m,n)=(n-1)*Pi/b*DNorm*DSQRT(2*Sigma/(a*b))*a*b/n01/n02

		ZB2te(m,n)=ZchainE11(m,n)*ZA2te(m,n)+ZchainE12(m,n)*ZA3te(m,n)
		ZB3te(m,n)=ZchainE21(m,n)*ZA2te(m,n)+ZchainE22(m,n)*ZA3te(m,n)

		ZB2th(m,n)=ZchainH11(m,n)*ZA2th(m,n)+ZchainH12(m,n)*ZA3th(m,n)
		ZB3th(m,n)=ZchainH21(m,n)*ZA2th(m,n)+ZchainH22(m,n)*ZA3th(m,n)
	                            
		ZB2mx(m,n)=-T22r(m,n)*ZB2th(m,n)+T21r(m,n)*ZB2te(m,n)
		ZB2nz(m,n)=T21r(m,n)*ZB2th(m,n)+T22r(m,n)*ZB2te(m,n)
              
		ZB3mx(m,n)=-T22r(m,n)*ZB3th(m,n)+T21r(m,n)*ZB3te(m,n)
		ZB3nz(m,n)=T21r(m,n)*ZB3th(m,n)+T22r(m,n)*ZB3te(m,n)                                      

  1   Continue

C     &&& ======= Murs a parois laterales Electriques =========== &&&

      If(IParois.EQ.1) Then
		Call fftcs(n01,n02,-1,ZB2mx)
          Call fftcs(n01,n02,-1,ZB3mx)
                        
          Call fftsc(n01,n02,-1,ZB2nz)
          Call fftsc(n01,n02,-1,ZB3nz)
                        
C     &&& ======= Murs a parois laterales Magnetiques =========== &&&
      Else
          Call fftsc(n01,n02,-1,ZB2mx)
          Call fftsc(n01,n02,-1,ZB3mx)

          Call fftcs(n01,n02,-1,ZB2nz)
          Call fftcs(n01,n02,-1,ZB3nz)
      Endif

      End

